"""
FR6 — Risk Prediction Model
Tech: scikit-learn  [BRD §9 — ML component]

Features (BRD FR6):
  • Balance (current account balance)
  • Debit amount (upcoming subscription total)
  • Historical failed debits
  • Upcoming debit amount

Output (BRD FR6):
  • Risk_Score  : float 0–1  (e.g. 0.78)
  • Risk_Level  : Low / Medium / High
  • Reason      : human-readable explanation

BRD §13 target: Risk prediction accuracy > 85%
BRD §8 Scenario 1: Single subscription + low balance → High risk
"""

import pandas as pd
import numpy as np

from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import (
    classification_report, confusion_matrix, roc_auc_score
)
from sklearn.pipeline import Pipeline


# ── Risk thresholds ───────────────────────────────────────────────────────────
RISK_LOW_THRESH  = 0.35
RISK_HIGH_THRESH = 0.65

FEATURE_COLS = [
    "Current_Balance",
    "Failed_Debit_Rate",
    "Avg_Debit_Amount",
    "Upcoming_Total_Debit",
    "Balance_To_Debit_Ratio",
    "Upcoming_Debit_Pct",
    "Total_Monthly_Sub_Amount",
    "Subscription_Count",
]


def _classify_risk(score: float) -> str:
    if score >= RISK_HIGH_THRESH:
        return "High"
    if score >= RISK_LOW_THRESH:
        return "Medium"
    return "Low"


def _build_reason(row: pd.Series) -> str:
    """Generate human-readable risk reason (BRD FR6 / FR7 Suggestion)."""
    reasons = []
    if row["Balance_To_Debit_Ratio"] < 1.5:
        reasons.append("Low balance relative to upcoming debit")
    if row["Failed_Debit_Rate"] > 0.10:
        reasons.append(f"High failure rate ({row['Failed_Debit_Rate']*100:.0f}%)")
    if row["Upcoming_Debit_Pct"] > 0.50:
        reasons.append("Upcoming debits exceed 50% of balance")
    if row["Total_Monthly_Sub_Amount"] > row["Current_Balance"] * 0.80:
        reasons.append("Monthly subscription burden > 80% of balance")
    if row["Subscription_Count"] >= 4:
        reasons.append(f"{int(row['Subscription_Count'])} active subscriptions")
    if not reasons:
        reasons.append("Stable balance and payment history")
    return "; ".join(reasons)


def build_risk_features(df: pd.DataFrame, pred_df: pd.DataFrame) -> pd.DataFrame:
    """
    Construct per-customer risk feature matrix from:
      • transaction history (df)
      • upcoming debit predictions (pred_df)
    """
    df = df.copy()
    df["Date"] = pd.to_datetime(df["Date"])

    # ── Per-customer aggregates ───────────────────────────────────────────────
    def _debit_rows(x):
        return df.loc[x.index[df.loc[x.index, "TransactionType"] == "DEBIT"], "Amount"]

    agg = df.groupby("CustomerID").agg(
        Current_Balance          = ("Balance",         "last"),
        Total_Transactions       = ("TransactionID",   "count"),
        Failed_Debits            = ("Status",          lambda x: (x == "FAILED").sum()),
        Total_Debits             = ("TransactionType", lambda x: (x == "DEBIT").sum()),
        Avg_Debit_Amount         = ("Amount",          lambda x:
                                    x[df.loc[x.index, "TransactionType"] == "DEBIT"].mean()),
        Total_Monthly_Sub_Amount = ("Amount",          lambda x:
                                    x[(df.loc[x.index, "Is_Recurring"] == 1) &
                                      (df.loc[x.index, "Inferred_Freq"] == "Monthly")].sum()),
        Subscription_Count       = ("Description_Clean", lambda x:
                                    x[(df.loc[x.index, "Is_Recurring"] == 1) &
                                      (df.loc[x.index, "Inferred_Freq"] == "Monthly")
                                     ].nunique()),
    ).reset_index()

    agg["Failed_Debit_Rate"] = (
        agg["Failed_Debits"] / agg["Total_Debits"].replace(0, 1)
    ).clip(0, 1)

    # ── Upcoming debit per customer ───────────────────────────────────────────
    upcoming = (
        pred_df.groupby("CustomerID")["Predicted_Amount"]
        .sum()
        .reset_index()
        .rename(columns={"Predicted_Amount": "Upcoming_Total_Debit"})
    )
    feat = agg.merge(upcoming, on="CustomerID", how="left")
    feat["Upcoming_Total_Debit"]    = feat["Upcoming_Total_Debit"].fillna(0)
    feat["Avg_Debit_Amount"]        = feat["Avg_Debit_Amount"].fillna(0)
    feat["Total_Monthly_Sub_Amount"]= feat["Total_Monthly_Sub_Amount"].fillna(0)
    feat["Subscription_Count"]      = feat["Subscription_Count"].fillna(0)

    # ── Derived ratio features (BRD FR6) ─────────────────────────────────────
    feat["Balance_To_Debit_Ratio"] = (
        feat["Current_Balance"] / feat["Upcoming_Total_Debit"].replace(0, 1)
    ).clip(0, 20)

    feat["Upcoming_Debit_Pct"] = (
        feat["Upcoming_Total_Debit"] / feat["Current_Balance"].replace(0, 1)
    ).clip(0, 5)

    # ── Synthetic risk label (for supervised training) ────────────────────────
    def _label(r):
        pct  = r["Upcoming_Debit_Pct"]
        fail = r["Failed_Debit_Rate"]
        subs = r["Subscription_Count"]
        if pct > 0.60 or fail > 0.15 or (pct > 0.40 and subs >= 3):
            return 2   # High
        if pct > 0.30 or fail > 0.05 or subs >= 3:
            return 1   # Medium
        return 0       # Low

    feat["Risk_Label"] = feat.apply(_label, axis=1)
    return feat


def train_risk_model(feat_df: pd.DataFrame):
    """
    Train Gradient Boosting risk classifier.

    Returns
    -------
    model      : fitted sklearn Pipeline
    scored_df  : feat_df with Risk_Score, Risk_Level, Risk_Reason columns
    """
    print(f"\n{'='*60}")
    print("  FR6 — RISK SCORING MODEL (Gradient Boosting)")
    print(f"{'='*60}")

    X = feat_df[FEATURE_COLS].fillna(0)
    y = feat_df["Risk_Label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    model = Pipeline([
        ("scaler", StandardScaler()),
        ("clf",    GradientBoostingClassifier(
            n_estimators=200,
            max_depth=4,
            learning_rate=0.07,
            subsample=0.8,
            random_state=42,
        )),
    ])

    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)

    print(f"\n  Train samples : {len(X_train):,}  |  Test : {len(X_test):,}")
    print(f"\n  Classification Report (BRD §13 target: >85% accuracy):")
    print(classification_report(y_test, y_pred,
                                target_names=["Low", "Medium", "High"]))

    cm = confusion_matrix(y_test, y_pred)
    print(f"  Confusion Matrix:")
    print(f"                Pred Low   Pred Med   Pred High")
    for i, lbl in enumerate(["Low", "Med", "High"]):
        print(f"  Actual {lbl:<5}  {cm[i,0]:>7,}  {cm[i,1]:>9,}  {cm[i,2]:>9,}")

    try:
        auc = roc_auc_score(y_test, y_prob, multi_class="ovr", average="weighted")
        print(f"\n  ROC-AUC (weighted OvR) : {auc:.4f}")
    except Exception:
        pass

    # ── Score all customers ───────────────────────────────────────────────────
    scored = feat_df.copy()
    all_prob = model.predict_proba(scored[FEATURE_COLS].fillna(0))
    # Risk score = 0·P(Low) + 0.5·P(Med) + 1·P(High)
    scored["Risk_Score"] = (0.0 * all_prob[:,0] +
                             0.5 * all_prob[:,1] +
                             1.0 * all_prob[:,2]).round(4)
    scored["Risk_Level"] = scored["Risk_Score"].apply(_classify_risk)
    scored["Risk_Reason"]= scored.apply(_build_reason, axis=1)

    # ── Distribution ─────────────────────────────────────────────────────────
    dist = scored["Risk_Level"].value_counts()
    print(f"\n  Risk Level Distribution:")
    for lvl in ["High", "Medium", "Low"]:
        cnt = dist.get(lvl, 0)
        pct = cnt / len(scored) * 100
        bar = "█" * int(pct / 2)
        print(f"  {lvl:<8}  {bar:<32}  {cnt:>5,}  ({pct:.1f}%)")

    # ── High-risk sample (BRD §8 Scenario 1) ─────────────────────────────────
    high = scored[scored["Risk_Level"] == "High"].sort_values("Risk_Score", ascending=False)
    print(f"\n  [Scenario 1] High-Risk Accounts (BRD §8):")
    if not high.empty:
        cols = ["CustomerID", "Current_Balance", "Upcoming_Total_Debit",
                "Failed_Debit_Rate", "Risk_Score", "Risk_Level", "Risk_Reason"]
        print(high[cols].head(5).to_string(index=False))

    print(f"{'='*60}\n")
    return model, scored


if __name__ == "__main__":
    df   = pd.read_csv("../data/transactions_patterns.csv")
    pred = pd.read_csv("../data/predictions.csv")
    feat = build_risk_features(df, pred)
    _, scored = train_risk_model(feat)
    print(scored[["CustomerID","Risk_Score","Risk_Level"]].head())
