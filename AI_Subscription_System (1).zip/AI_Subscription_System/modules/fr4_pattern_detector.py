"""
FR4 — Recurring Pattern Detection
Tech: Python + Pandas  (BRD §9)

Detects:
  • Frequency (Weekly / Monthly / Irregular)  [BRD FR4]
  • Recurring dates per CustomerID × Description
  • Minimum occurrences before confirming recurrence (≥ 3)
  • Handles Feb/month-end date drift  [BRD §8 Scenario 3]
  • Flags multiple subscriptions on the same date  [BRD §8 Scenario 2]

FR8 Insights:
  • Count of active subscriptions per customer
  • Total monthly subscription spend per customer
"""

import pandas as pd
import numpy as np
from datetime import timedelta


MIN_OCCURRENCES  = 3       # BRD: minimum hits to confirm
WEEKLY_BAND      = (5, 9)  # days — ≈7 ± 2
MONTHLY_BAND     = (25, 35) # days — ≈30 ± 5


def _infer_frequency(gaps: list) -> str:
    if not gaps:
        return "Irregular"
    med = np.median(gaps)
    if WEEKLY_BAND[0] <= med <= WEEKLY_BAND[1]:
        return "Weekly"
    if MONTHLY_BAND[0] <= med <= MONTHLY_BAND[1]:
        return "Monthly"
    return "Irregular"


def detect_recurring_patterns(df: pd.DataFrame) -> tuple:
    """
    Identify recurring subscription patterns.

    Steps
    -----
    1. Filter to NLP-predicted subscriptions + DEBIT.
    2. Group by (CustomerID, Description_Clean).
    3. Sort dates, compute inter-transaction gaps.
    4. Infer frequency; require MIN_OCCURRENCES.
    5. Flag in main df; produce summary table.
    6. Generate FR8 customer-level insights.

    Returns
    -------
    df_annotated  : original df with added columns:
                    Is_Recurring, Inferred_Freq, Occurrence_Count
    summary_df    : one row per confirmed recurring group
    insights_df   : per-customer subscription summary  (FR8)
    """
    print(f"\n{'='*60}")
    print("  FR4 — RECURRING PATTERN DETECTION")
    print(f"{'='*60}")

    df = df.copy()
    df["Date"] = pd.to_datetime(df["Date"])

    # Initialise output columns
    df["Is_Recurring"]     = 0
    df["Inferred_Freq"]    = "None"
    df["Occurrence_Count"] = 0

    pred_col = "NLP_Sub_Pred" if "NLP_Sub_Pred" in df.columns else "SubscriptionFlag"
    sub_mask = (
        (df[pred_col] == 1) &
        (df["TransactionType"] == "DEBIT")
    )
    sub_df = df[sub_mask].copy()

    recurring_rows = []
    groups_total   = 0
    groups_confirmed = 0

    for (cust_id, desc), grp in sub_df.groupby(["CustomerID", "Description_Clean"]):
        groups_total += 1
        grp_s  = grp.sort_values("Date")
        dates  = grp_s["Date"].tolist()

        if len(dates) < MIN_OCCURRENCES:
            continue

        gaps = [(dates[i] - dates[i-1]).days for i in range(1, len(dates))]
        freq = _infer_frequency(gaps)

        if freq == "Irregular":
            continue

        groups_confirmed += 1

        # Mark rows in main df
        df.loc[grp_s.index, "Is_Recurring"]     = 1
        df.loc[grp_s.index, "Inferred_Freq"]    = freq
        df.loc[grp_s.index, "Occurrence_Count"] = len(dates)

        recurring_rows.append({
            "CustomerID":       cust_id,
            "Description":      desc,
            "Merchant":         grp_s["Merchant"].mode().iloc[0]
                                if not grp_s["Merchant"].empty else "Unknown",
            "Frequency":        freq,
            "Occurrences":      len(dates),
            "First_Date":       dates[0].date(),
            "Last_Date":        dates[-1].date(),
            "Avg_Amount":       round(grp_s["Amount"].mean(), 2),
            "Std_Amount":       round(grp_s["Amount"].std(), 2),
            "Median_Gap_Days":  round(np.median(gaps), 1),
            "Failed_Count":     int((grp_s["Status"] == "FAILED").sum()),
        })

    summary_df = pd.DataFrame(recurring_rows)

    # ── Console report ────────────────────────────────────────────────────────
    print(f"\n  Groups analysed       : {groups_total:,}")
    print(f"  Confirmed recurring   : {groups_confirmed:,}")
    print(f"  Rows flagged          : {df['Is_Recurring'].sum():,}")

    if not summary_df.empty:
        freq_dist = summary_df["Frequency"].value_counts()
        print(f"\n  Frequency breakdown:")
        for freq, cnt in freq_dist.items():
            print(f"      {freq:<12} : {cnt:,}")

    # ── Scenario 2: same-date multi-subscription accounts (BRD §8) ────────────
    recurring_debits = df[(df["Is_Recurring"] == 1) &
                          (df["TransactionType"] == "DEBIT")]
    same_date = (
        recurring_debits.groupby(["CustomerID", "Date"])
        .size()
        .reset_index(name="sub_count")
    )
    multi = same_date[same_date["sub_count"] > 1]
    print(f"\n  [Scenario 2] Accounts with multiple subs on same date: "
          f"{multi['CustomerID'].nunique():,}")
    if not multi.empty:
        print(f"  Sample same-date multi-debit days:")
        print(multi.head(4).to_string(index=False))

    # ── Sample output ─────────────────────────────────────────────────────────
    print(f"\n  Sample confirmed recurring subscriptions:")
    if not summary_df.empty:
        print(summary_df[["CustomerID","Description","Frequency",
                           "Occurrences","Avg_Amount","Median_Gap_Days",
                           "Failed_Count"]].head(8).to_string(index=False))

    # ── FR8 — Customer-level insights ─────────────────────────────────────────
    if not summary_df.empty:
        monthly_subs = summary_df[summary_df["Frequency"] == "Monthly"]
        insights = (
            monthly_subs.groupby("CustomerID")
            .agg(
                Active_Subscriptions = ("Description", "count"),
                Total_Monthly_Spend  = ("Avg_Amount",  "sum"),
                Merchants            = ("Merchant",    lambda x: ", ".join(x.unique()[:3])),
            )
            .reset_index()
        )
        insights["Total_Monthly_Spend"] = insights["Total_Monthly_Spend"].round(2)

        print(f"\n  ── FR8 Insights: Customer Subscription Summary ──")
        print(f"  Customers with active monthly subscriptions: "
              f"{len(insights):,}")
        avg_subs  = insights["Active_Subscriptions"].mean()
        avg_spend = insights["Total_Monthly_Spend"].mean()
        print(f"  Avg subscriptions per customer : {avg_subs:.1f}")
        print(f"  Avg monthly spend              : ₹{avg_spend:,.2f}")
        print(f"\n  Sample customer insights:")
        print(insights.head(6).to_string(index=False))
    else:
        insights = pd.DataFrame()

    print(f"{'='*60}\n")
    return df, summary_df, insights


if __name__ == "__main__":
    df = pd.read_csv("../data/transactions_nlp.csv")
    df, summary, insights = detect_recurring_patterns(df)
    print(summary.head())
