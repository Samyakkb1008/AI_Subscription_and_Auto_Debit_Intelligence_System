"""
FR1 / BRD §12 — Synthetic Dataset Generator
Tech: Python + Faker  (BRD §9 / §12)

Generates 50K–200K realistic banking transactions with:
  • CustomerID, Transaction Date, Description, Amount, Balance,
    Merchant, Subscription Flag  (BRD §12 Required Fields)
  • Monthly & weekly recurring payments
  • Balance fluctuations
  • Missed / failed payments
  • Intentional nulls in Amount, Balance, Description (for FR2 cleaning demo)

Business Logic per BRD §12:
  • Fixed subscription amounts with small jitter
  • Salary credits maintain realistic balance cycles
  • 7% debit failure rate on subscriptions
"""

import pandas as pd
import numpy as np
import random
import os
from datetime import datetime, timedelta

try:
    from faker import Faker
    fake = Faker("en_IN")          # Indian locale for realistic bank data
    FAKER_AVAILABLE = True
except ImportError:
    FAKER_AVAILABLE = False
    print("[DatasetGen] ⚠  Faker not installed — using built-in name lists.")

SEED = 42
np.random.seed(SEED)
random.seed(SEED)

# ── Subscription catalogue (BRD FR3 examples + Indian market) ────────────────
SUBSCRIPTIONS = [
    # name,                        merchant,            amount,  freq
    ("NETFLIX.COM MONTHLY SUB",    "Netflix",           649.0,   "monthly"),
    ("SPOTIFY PREMIUM MONTHLY",    "Spotify",           119.0,   "monthly"),
    ("AMAZON PRIME SUBSCRIPTION",  "Amazon",            299.0,   "monthly"),
    ("YOUTUBE PREMIUM MONTHLY",    "YouTube",           189.0,   "monthly"),
    ("HOTSTAR PREMIUM",            "Disney+Hotstar",   1499.0,   "monthly"),
    ("APPLE ICLOUD STORAGE",       "Apple",              75.0,   "monthly"),
    ("GOOGLE ONE STORAGE PLAN",    "Google",            130.0,   "monthly"),
    ("MICROSOFT 365 SUBSCRIPTION", "Microsoft",         499.0,   "monthly"),
    ("ZEE5 PREMIUM PLAN",          "Zee5",               99.0,   "monthly"),
    ("SWIGGY ONE MEMBERSHIP",      "Swiggy",            179.0,   "monthly"),
    ("LINKEDIN PREMIUM CAREER",    "LinkedIn",         2650.0,   "monthly"),
    ("DROPBOX PLUS PLAN",          "Dropbox",           899.0,   "monthly"),
    ("ADOBE CREATIVE CLOUD",       "Adobe",            1675.0,   "monthly"),
    ("ZOOM PRO MONTHLY",           "Zoom",             1300.0,   "monthly"),
    ("COURSERA PLUS MONTHLY",      "Coursera",         3999.0,   "monthly"),
    ("ELECTRICITY BILL AUTO PAY",  "BESCOM",            850.0,   "monthly"),
    ("GYM MEMBERSHIP MONTHLY",     "CultFit",           999.0,   "monthly"),
    # Weekly
    ("NEWSPAPER DIGITAL WEEKLY",   "TimesOfIndia",       49.0,   "weekly"),
    ("GYM LOCKER WEEKLY",          "AnytimeFitness",    249.0,   "weekly"),
]

# Edge-case descriptions (BRD FR3 — ambiguous)
AMBIGUOUS_DESCRIPTIONS = [
    ("AUTO PAY 4521",          "AutoPay",    None,  "monthly"),
    ("ACH DEBIT 00293",        "ACH",        None,  "monthly"),
    ("NACH DEBIT MANDATE",     "NACH",       None,  "monthly"),
    ("STANDING INSTRUCTION",   "SI",         None,  "monthly"),
    ("RECURRING TRANSFER REF", "Bank",       None,  "monthly"),
    ("PERIODIC PAYMENT 7734",  "AutoDebit",  None,  "monthly"),
]

# Non-subscription transactions (BRD FR3 false-positive prevention)
NON_SUBSCRIPTIONS = [
    ("MONTHLY SALARY CREDIT",  "Employer",    None,   "credit"),
    ("ATM CASH WITHDRAWAL",    "ATM",         None,   "debit"),
    ("GROCERY PURCHASE",       "BigBasket",   None,   "debit"),
    ("FUEL PETROL PUMP",       "HPCL",        None,   "debit"),
    ("RESTAURANT SWIGGY",      "Swiggy",      None,   "debit"),
    ("ELECTRICITY BILL BPAY",  "BESCOM",      None,   "debit"),
    ("MOBILE RECHARGE",        "Jio",         None,   "debit"),
    ("ONLINE SHOPPING",        "Flipkart",    None,   "debit"),
    ("UPI TRANSFER",           "PhonePe",     None,   "debit"),
    ("NEFT TRANSFER OUTWARD",  "Bank",        None,   "debit"),
    ("IMPS TRANSFER",          "Bank",        None,   "debit"),
    ("MEDICAL PHARMACY",       "MedPlus",     None,   "debit"),
    ("HOTEL BOOKING OYO",      "OYO",         None,   "debit"),
    ("FLIGHT TICKET IRCTC",    "IRCTC",       None,   "debit"),
    ("INTEREST CREDIT",        "Bank",        None,   "credit"),
    ("TAX REFUND CREDIT",      "IncomeTax",   None,   "credit"),
    ("CASH DEPOSIT ATM",       "ATM",         None,   "credit"),
    ("INSURANCE PREMIUM LIC",  "LIC",         None,   "debit"),
    ("LOAN EMI SBI",           "SBI",         None,   "debit"),
    ("RENT PAYMENT NEFT",      "Landlord",    None,   "debit"),
]

FIRST_NAMES = ["Aarav","Ananya","Rohan","Priya","Vikram","Meera","Arjun","Sneha",
               "Karan","Pooja","Rahul","Deepa","Amit","Kavya","Suresh","Lakshmi"]
LAST_NAMES  = ["Sharma","Patel","Singh","Nair","Reddy","Gupta","Kumar","Verma",
               "Joshi","Shah","Das","Rao","Pillai","Mehta","Chopra","Iyer"]


def _fake_name():
    if FAKER_AVAILABLE:
        return fake.name()
    return f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"


def _jitter(amount: float, pct: float = 0.04) -> float:
    return round(amount * (1 + np.random.uniform(-pct, pct)), 2)


def _advance_month(dt: datetime) -> datetime:
    """Advance by one month, handling Feb/month-end drift (BRD FR4 / FR5)."""
    month = dt.month + 1
    year  = dt.year + (1 if month > 12 else 0)
    month = month if month <= 12 else 1
    day   = min(dt.day, 28 if month == 2 else 30)
    return dt.replace(year=year, month=month, day=day)


def _generate_account(account_id: str, customer_name: str,
                       start: datetime, end: datetime,
                       subs: list) -> list:
    """Generate all transactions for one customer account."""
    records = []
    balance = round(np.random.uniform(8_000, 200_000), 2)

    # ── salary credit each month (keeps balance realistic) ───────────────────
    salary = round(np.random.uniform(25_000, 150_000), 2)
    sal_dt = start.replace(day=1) + timedelta(days=random.randint(0, 3))
    while sal_dt <= end:
        balance += salary
        records.append({
            "CustomerID":        account_id,
            "CustomerName":      customer_name,
            "TransactionID":     f"TXN{random.randint(10_000_000, 99_999_999)}",
            "Date":              sal_dt.strftime("%Y-%m-%d"),
            "Description":       "MONTHLY SALARY CREDIT",
            "Amount":            salary,
            "Balance":           round(balance, 2),
            "Merchant":          "Employer",
            "TransactionType":   "CREDIT",
            "SubscriptionFlag":  0,
            "Status":            "SUCCESS",
            "Frequency":         "monthly",
        })
        sal_dt = _advance_month(sal_dt)

    # ── recurring subscriptions ───────────────────────────────────────────────
    for (desc, merchant, amount, freq) in subs:
        base_amount = amount if amount else round(np.random.uniform(50, 2000), 2)
        dt = start + timedelta(days=random.randint(0, 27))

        while dt <= end:
            failed  = random.random() < 0.07
            amt     = _jitter(base_amount)
            null_amt = random.random() < 0.022
            null_bal = random.random() < 0.020
            null_desc= random.random() < 0.008

            if not failed:
                balance -= amt

            records.append({
                "CustomerID":        account_id,
                "CustomerName":      customer_name,
                "TransactionID":     f"TXN{random.randint(10_000_000, 99_999_999)}",
                "Date":              dt.strftime("%Y-%m-%d"),
                "Description":       None if null_desc else desc,
                "Amount":            None if null_amt else round(amt, 2),
                "Balance":           None if null_bal else round(balance, 2),
                "Merchant":          merchant,
                "TransactionType":   "DEBIT",
                "SubscriptionFlag":  1,
                "Status":            "FAILED" if failed else "SUCCESS",
                "Frequency":         freq,
            })

            if freq == "monthly":
                dt = _advance_month(dt)
            else:
                dt += timedelta(weeks=1)

    # ── ambiguous edge-case transactions ─────────────────────────────────────
    for (desc, merchant, amount, freq) in random.sample(AMBIGUOUS_DESCRIPTIONS,
                                                         k=random.randint(1, 3)):
        dt  = start + timedelta(days=random.randint(0, (end - start).days))
        amt = amount if amount else round(np.random.uniform(100, 3000), 2)
        balance -= amt
        records.append({
            "CustomerID":        account_id,
            "CustomerName":      customer_name,
            "TransactionID":     f"TXN{random.randint(10_000_000, 99_999_999)}",
            "Date":              dt.strftime("%Y-%m-%d"),
            "Description":       desc,
            "Amount":            round(amt, 2),
            "Balance":           round(balance, 2),
            "Merchant":          merchant,
            "TransactionType":   "DEBIT",
            "SubscriptionFlag":  0,
            "Status":            "SUCCESS",
            "Frequency":         freq,
        })

    # ── random non-subscription transactions ─────────────────────────────────
    n_rand = random.randint(15, 50)
    for _ in range(n_rand):
        dt = start + timedelta(days=random.randint(0, (end - start).days))
        (desc, merchant, _, txn_type) = random.choice(NON_SUBSCRIPTIONS)
        is_debit = txn_type == "debit"
        amt = round(np.random.lognormal(7.5, 1.2), 2)
        null_amt  = random.random() < 0.025
        null_bal  = random.random() < 0.018
        null_desc = random.random() < 0.006

        if is_debit:
            balance -= amt
        else:
            balance += amt

        records.append({
            "CustomerID":        account_id,
            "CustomerName":      customer_name,
            "TransactionID":     f"TXN{random.randint(10_000_000, 99_999_999)}",
            "Date":              dt.strftime("%Y-%m-%d"),
            "Description":       None if null_desc else desc,
            "Amount":            None if null_amt else round(amt, 2),
            "Balance":           None if null_bal else round(balance, 2),
            "Merchant":          merchant,
            "TransactionType":   "CREDIT" if not is_debit else "DEBIT",
            "SubscriptionFlag":  0,
            "Status":            "SUCCESS",
            "Frequency":         "none",
        })

    return records


def generate_dataset(n_accounts: int = 1200,
                     output_path: str = None) -> pd.DataFrame:
    """
    Generate synthetic banking transaction dataset.

    Parameters
    ----------
    n_accounts  : number of unique customer accounts
    output_path : optional CSV save path

    Returns
    -------
    pd.DataFrame  with columns matching BRD §12 Required Fields
    """
    print(f"\n{'='*60}")
    print("  FR1/§12 — SYNTHETIC DATASET GENERATION (Faker)")
    print(f"{'='*60}")
    print(f"  Accounts      : {n_accounts:,}")

    start = datetime(2023, 1, 1)
    end   = datetime(2024, 6, 30)
    all_records = []

    for i in range(n_accounts):
        acct_id  = f"CUST{100_000 + i}"
        name     = _fake_name()
        # 1-4 subscriptions per customer
        acct_subs = random.sample(SUBSCRIPTIONS, k=random.randint(1, 4))
        all_records.extend(
            _generate_account(acct_id, name, start, end, acct_subs)
        )

    df = pd.DataFrame(all_records)
    df["Date"] = pd.to_datetime(df["Date"])
    df.sort_values(["CustomerID", "Date"], inplace=True)
    df.reset_index(drop=True, inplace=True)

    sub_count  = df["SubscriptionFlag"].sum()
    null_amt   = df["Amount"].isna().sum()
    null_bal   = df["Balance"].isna().sum()
    null_desc  = df["Description"].isna().sum()
    failed     = (df["Status"] == "FAILED").sum()

    print(f"  Total rows    : {len(df):,}")
    print(f"  Subscriptions : {sub_count:,}  ({sub_count/len(df)*100:.1f}%)")
    print(f"  Failed debits : {failed:,}")
    print(f"  Null — Amount : {null_amt:,}  ({null_amt/len(df)*100:.2f}%)")
    print(f"  Null — Balance: {null_bal:,}  ({null_bal/len(df)*100:.2f}%)")
    print(f"  Null — Desc   : {null_desc:,}  ({null_desc/len(df)*100:.2f}%)")

    if output_path:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        df.to_csv(output_path, index=False)
        print(f"  Saved → {output_path}")

    print(f"{'='*60}\n")
    return df


if __name__ == "__main__":
    df = generate_dataset(n_accounts=1200,
                          output_path="../data/transactions_raw.csv")
    print(df[["CustomerID","Date","Description","Amount","Balance",
              "Merchant","SubscriptionFlag"]].head(10).to_string())
