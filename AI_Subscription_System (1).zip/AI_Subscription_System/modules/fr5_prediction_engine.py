"""
FR5 — Debit Prediction (ML Model)
Tech: Time Series (ARIMA via statsmodels) + Regression (scikit-learn)  [BRD §9]

Predicts:
  • Next Debit Date   — date extrapolation (linear trend + median gap)
  • Next Debit Amount — ARIMA on amount time-series (fallback: EWM regression)

BRD §8 Scenario 3: handles Feb/month-end date drift
BRD FR5 example: Jan 5 → Feb 5 → Mar 5 → Pred Apr 5
"""

import pandas as pd
import numpy as np
from datetime import timedelta, date

from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score

# ARIMA via statsmodels
try:
    from statsmodels.tsa.arima.model import ARIMA
    ARIMA_AVAILABLE = True
except ImportError:
    ARIMA_AVAILABLE = False
    print("[Prediction] ⚠  statsmodels not installed — using EWM fallback for amounts.")

# Prophet (optional)
try:
    from prophet import Prophet
    PROPHET_AVAILABLE = True
except ImportError:
    PROPHET_AVAILABLE = False


def _predict_next_date(dates: list, freq: str) -> date:
    """
    Predict the next occurrence date.
    Method: linear regression on date ordinals (smoothed) + median-gap blend.
    Handles Feb/month-end drift (BRD §8 Scenario 3).
    """
    if len(dates) < 2:
        return (dates[-1] + timedelta(days=30 if freq == "Monthly" else 7)).date()

    gaps    = [(dates[i] - dates[i-1]).days for i in range(1, len(dates))]
    med_gap = int(np.median(gaps))

    # Linear regression on ordinal days
    ordinals = np.array([d.toordinal() for d in dates]).reshape(-1, 1)
    indices  = np.arange(len(dates)).reshape(-1, 1)
    lr       = LinearRegression()
    lr.fit(indices, ordinals)
    next_ord  = int(np.ravel(lr.predict([[len(dates)]]))[0])
    lr_date   = pd.Timestamp.fromordinal(max(next_ord, dates[-1].toordinal() + 1))

    # Blend: 70% linear regression + 30% median gap
    gap_pred = dates[-1] + timedelta(days=med_gap)
    blended_days = int(0.7 * (lr_date - dates[-1]).days + 0.3 * med_gap)
    blended_days = max(blended_days, 1)
    predicted = dates[-1] + timedelta(days=blended_days)
    return predicted.date()


def _predict_amount_arima(amounts: list) -> float:
    """Fit ARIMA(1,0,0) on amount series and predict next value."""
    if not ARIMA_AVAILABLE or len(amounts) < 4:
        return _predict_amount_ewm(amounts)
    try:
        model  = ARIMA(amounts, order=(1, 0, 0))
        result = model.fit()
        pred   = float(result.forecast(steps=1)[0])
        return round(max(pred, 0), 2)
    except Exception:
        return _predict_amount_ewm(amounts)


def _predict_amount_ewm(amounts: list) -> float:
    """Exponentially weighted mean — recent observations matter more."""
    if len(amounts) == 1:
        return round(amounts[0], 2)
    weights = np.exp(np.linspace(0, 1, len(amounts)))
    weights /= weights.sum()
    return round(float(np.dot(weights, amounts)), 2)


def predict_next_debits(df: pd.DataFrame) -> pd.DataFrame:
    """
    For every confirmed recurring subscription, predict:
      • Next_Debit_Date
      • Predicted_Amount
      • Prediction_Method

    Returns
    -------
    pd.DataFrame — one row per CustomerID × subscription
    """
    print(f"\n{'='*60}")
    print("  FR5 — NEXT DEBIT DATE & AMOUNT PREDICTION")
    print(f"  ARIMA available : {ARIMA_AVAILABLE}")
    print(f"  Prophet available: {PROPHET_AVAILABLE}")
    print(f"{'='*60}")

    df = df.copy()
    df["Date"] = pd.to_datetime(df["Date"])

    recurring = df[
        (df["Is_Recurring"] == 1) &
        (df["TransactionType"] == "DEBIT") &
        (df["Status"] == "SUCCESS")
    ]

    predictions = []
    groups = recurring.groupby(["CustomerID", "Description_Clean"])

    for (cust_id, desc), grp in groups:
        grp_s   = grp.sort_values("Date")
        dates   = grp_s["Date"].tolist()
        amounts = grp_s["Amount"].tolist()
        freq    = grp_s["Inferred_Freq"].iloc[0]

        if len(dates) < 2:
            continue

        next_date = _predict_next_date(dates, freq)

        # Amount prediction: ARIMA if enough data, else EWM
        if ARIMA_AVAILABLE and len(amounts) >= 4:
            next_amount = _predict_amount_arima(amounts)
            method = "ARIMA(1,0,0)"
        else:
            next_amount = _predict_amount_ewm(amounts)
            method = "EWM Regression"

        # Date sequence for display (BRD FR5 example format)
        seq_labels = " → ".join(d.strftime("%b %d") for d in dates[-3:])
        seq_labels += f"  →  {next_date.strftime('%b %d')} (pred)"

        predictions.append({
            "CustomerID":          cust_id,
            "Subscription":        desc,
            "Merchant":            grp_s["Merchant"].mode().iloc[0]
                                   if "Merchant" in grp_s.columns else "—",
            "Frequency":           freq,
            "Occurrences":         len(dates),
            "Last_Debit_Date":     dates[-1].date(),
            "Next_Debit_Date":     next_date,
            "Avg_Historical_Amt":  round(np.mean(amounts), 2),
            "Predicted_Amount":    next_amount,
            "Prediction_Method":   method,
            "Date_Sequence":       seq_labels,
        })

    pred_df = pd.DataFrame(predictions)

    # ── Console output ────────────────────────────────────────────────────────
    print(f"\n  Customer-subscription pairs predicted : {len(pred_df):,}")

    if not pred_df.empty:
        print(f"\n  Sample Predictions (BRD FR5):")
        display = pred_df[[
            "CustomerID","Subscription","Frequency",
            "Last_Debit_Date","Next_Debit_Date","Predicted_Amount",
            "Prediction_Method"
        ]].head(8)
        print(display.to_string(index=False))

        print(f"\n  Date Sequences (last 3 → prediction):")
        for _, row in pred_df.head(5).iterrows():
            print(f"    [{row['Subscription'][:35]:<35}]  {row['Date_Sequence']}")

        # ── Leave-one-out amount evaluation ──────────────────────────────────
        eval_rows = []
        for (cust_id, desc), grp in groups:
            grp_s = grp.sort_values("Date")
            amts  = grp_s["Amount"].tolist()
            if len(amts) >= 4:
                train  = amts[:-1]
                actual = amts[-1]
                pred   = (_predict_amount_arima(train)
                          if ARIMA_AVAILABLE else _predict_amount_ewm(train))
                eval_rows.append({"actual": actual, "predicted": pred})

        if eval_rows:
            eval_df = pd.DataFrame(eval_rows)
            mae = mean_absolute_error(eval_df["actual"], eval_df["predicted"])
            r2  = r2_score(eval_df["actual"], eval_df["predicted"])
            print(f"\n  Amount Prediction Evaluation (leave-one-out):")
            print(f"    MAE : ₹{mae:.2f}")
            print(f"    R²  : {r2:.4f}")
            print(f"    Method: {'ARIMA(1,0,0)' if ARIMA_AVAILABLE else 'EWM Regression'}")

    print(f"{'='*60}\n")
    return pred_df


if __name__ == "__main__":
    df   = pd.read_csv("../data/transactions_patterns.csv")
    pred = predict_next_debits(df)
    print(pred.head())
