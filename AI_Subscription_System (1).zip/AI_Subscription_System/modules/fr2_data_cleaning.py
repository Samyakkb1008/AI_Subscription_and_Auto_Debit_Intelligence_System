"""
FR2 — Data Processing / Cleaning
Tech: Python + Pandas  (BRD §9)

Steps:
  1. Log null counts BEFORE (visible preprocessing change)
  2. Fill Amount nulls  — group-median per Merchant, fallback overall
  3. Fill Balance nulls — forward-fill within CustomerID, then backfill
  4. Fill Description nulls → 'UNKNOWN TRANSACTION'
  5. Normalise / clean text descriptions
  6. Enforce dtypes
  7. Remove duplicate TransactionIDs
  8. Log null counts AFTER (shows visible change)

BRD §10: <10 sec processing target
"""

import pandas as pd
import numpy as np
import re
import os


# ── Text normalisation rules ──────────────────────────────────────────────────

_SYNONYMS = {
    r'\bMTHLY\b':    'MONTHLY',
    r'\bMO\b':       'MONTHLY',
    r'\bWKLY\b':     'WEEKLY',
    r'\bSUBS?\b':    'SUBSCRIPTION',
    r'\bPYMT\b':     'PAYMENT',
    r'\bPMT\b':      'PAYMENT',
    r'\bRCRNG\b':    'RECURRING',
    r'\bREC\b':      'RECURRING',
    r'\bACT\b':      'AUTO',
    r'\bDR\b':       'DEBIT',
    r'\bCR\b':       'CREDIT',
    r'\bTRFR\b':     'TRANSFER',
    r'\bWDL\b':      'WITHDRAWAL',
}


def _normalise_text(text: str) -> str:
    """Uppercase, expand abbreviations, strip noise, collapse whitespace."""
    if pd.isna(text) or not isinstance(text, str):
        return "UNKNOWN TRANSACTION"
    t = text.upper().strip()
    for pattern, repl in _SYNONYMS.items():
        t = re.sub(pattern, repl, t)
    # Remove stray symbols (keep letters, digits, spaces, dot, dash)
    t = re.sub(r'[^A-Z0-9\s\.\-/]', ' ', t)
    t = re.sub(r'\s{2,}', ' ', t).strip()
    return t


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Apply FR2 preprocessing pipeline.

    Returns cleaned DataFrame with additional column `Description_Clean`.
    """
    print(f"\n{'='*60}")
    print("  FR2 — DATA CLEANING & PREPROCESSING")
    print(f"{'='*60}")

    df = df.copy()
    total = len(df)
    print(f"\n  Input rows    : {total:,}")

    # ── BEFORE audit ─────────────────────────────────────────────────────────
    nulls_before = df.isnull().sum()
    critical_cols = ["Description", "Amount", "Balance"]
    print("\n  [Pre-Cleaning] Null counts:")
    for col in critical_cols:
        cnt = nulls_before.get(col, 0)
        print(f"      {col:<20} {cnt:>6,}  ({cnt/total*100:.2f}%)")

    # ── Step 1: Amount nulls — group-median imputation ────────────────────────
    null_amt_idx = df["Amount"].isna()
    merchant_med = df.groupby("Merchant")["Amount"].transform("median")
    overall_med  = df["Amount"].median()
    df.loc[null_amt_idx, "Amount"] = merchant_med[null_amt_idx].fillna(overall_med)
    print(f"\n  [Step 1] Amount nulls filled   : {null_amt_idx.sum():,}"
          f"  (merchant-median imputation)")

    # ── Step 2: Balance nulls — forward-fill within account ──────────────────
    null_bal_idx = df["Balance"].isna()
    df = df.sort_values(["CustomerID", "Date"])
    df["Balance"] = (
        df.groupby("CustomerID")["Balance"]
        .transform(lambda s: s.ffill().bfill())
    )
    df["Balance"] = df["Balance"].fillna(df["Balance"].median())
    print(f"  [Step 2] Balance nulls filled  : {null_bal_idx.sum():,}"
          f"  (forward-fill within account)")

    # ── Step 3: Description nulls → placeholder ───────────────────────────────
    null_desc_idx = df["Description"].isna()
    df["Description"] = df["Description"].fillna("UNKNOWN TRANSACTION")
    print(f"  [Step 3] Description nulls     : {null_desc_idx.sum():,}"
          f"  → 'UNKNOWN TRANSACTION'")

    # ── Step 4: Normalise text → Description_Clean ───────────────────────────
    df["Description_Clean"] = df["Description"].apply(_normalise_text)
    print(f"  [Step 4] Description normalised → 'Description_Clean' column")

    # ── Step 5: Dtype enforcement ─────────────────────────────────────────────
    df["Date"]    = pd.to_datetime(df["Date"])
    df["Amount"]  = df["Amount"].astype(float).round(2)
    df["Balance"] = df["Balance"].astype(float).round(2)
    print(f"  [Step 5] Dtypes enforced: Date→datetime64, Amount/Balance→float64")

    # ── Step 6: Remove duplicate TransactionIDs ───────────────────────────────
    dups = df.duplicated(subset=["TransactionID"]).sum()
    df   = df.drop_duplicates(subset=["TransactionID"])
    df.reset_index(drop=True, inplace=True)
    print(f"  [Step 6] Duplicate rows removed: {dups:,}")

    # ── AFTER audit ──────────────────────────────────────────────────────────
    nulls_after = df.isnull().sum()
    remaining   = nulls_after[critical_cols].sum()
    print(f"\n  [Post-Cleaning] Output rows    : {len(df):,}")
    if remaining == 0:
        print("  [Post-Cleaning] ✅ Zero nulls remaining in critical columns.")
    else:
        print("  [Post-Cleaning] Remaining nulls:")
        for col in critical_cols:
            cnt = nulls_after.get(col, 0)
            if cnt > 0:
                print(f"      {col:<20} {cnt:>6,}")

    # Sample transformation display
    print("\n  [Sample] Description normalisation (before → after):")
    sample = df[["Description","Description_Clean"]].drop_duplicates().head(6)
    for _, row in sample.iterrows():
        print(f"      '{row['Description']}'  →  '{row['Description_Clean']}'")

    print(f"{'='*60}\n")
    return df


if __name__ == "__main__":
    raw = pd.read_csv("../data/transactions_raw.csv")
    cleaned = clean_data(raw)
    cleaned.to_csv("../data/transactions_cleaned.csv", index=False)
