"""
FR3 — NLP-Based Subscription Detection
Tech: spaCy  (BRD §9 — NLP component)

Approach (multi-layer):
  Layer 1 : spaCy tokenisation + lemmatisation + POS-based feature extraction
  Layer 2 : spaCy PhraseMatcher for subscription & false-positive patterns
  Layer 3 : Scikit-learn TF-IDF + Logistic Regression trained on spaCy features
  Layer 4 : Rule-based false-positive guard (salary, refund, etc.)

Edge cases handled (BRD FR3):
  • "AUTO PAY 4521"         — ambiguous → classified on probability
  • "ACH DEBIT 00293"       — ambiguous → classified on probability
  • "MONTHLY SALARY CREDIT" — ❌ NOT a subscription (false-positive guard)
  • "NETFLIX.COM MONTHLY SUB" → ✅ Subscription

Evaluation target: ≥ 90% accuracy (BRD §13)
"""

import re
import os
import pandas as pd
import numpy as np

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.metrics import (
    classification_report, confusion_matrix,
    accuracy_score, precision_score, recall_score, f1_score,
)

# ── spaCy import (with graceful fallback for environments without it) ─────────
try:
    import spacy
    # Load small English model
    try:
        nlp = spacy.load("en_core_web_sm")
        SPACY_AVAILABLE = True
    except OSError:
        print("[NLP] ⚠  en_core_web_sm not found. Run: python -m spacy download en_core_web_sm")
        print("[NLP]    Falling back to spaCy blank English model.")
        nlp = spacy.blank("en")
        SPACY_AVAILABLE = True
except ImportError:
    print("[NLP] ⚠  spaCy not installed. Run: pip install spacy")
    print("[NLP]    Falling back to regex-only pipeline.")
    SPACY_AVAILABLE = False
    nlp = None


# ── Vocabulary lists ──────────────────────────────────────────────────────────

SUBSCRIPTION_PHRASES = [
    "monthly sub", "subscription", "premium", "membership", "annual plan",
    "netflix", "spotify", "amazon prime", "youtube premium", "hotstar",
    "apple icloud", "google one", "microsoft 365", "zee5", "swiggy one",
    "linkedin premium", "dropbox", "adobe creative", "zoom pro", "coursera",
    "gym membership", "digital plan", "auto renewal", "autorenew",
    "electricity bill", "utility bill",
]

FALSE_POSITIVE_PHRASES = [
    "salary credit", "salary", "wages", "payroll", "bonus", "stipend",
    "interest credit", "tax refund", "refund", "dividend",
    "cash deposit", "atm deposit",
]

SUBSCRIPTION_TOKENS = {
    "subscription", "sub", "premium", "membership", "monthly", "weekly",
    "annual", "renewal", "netflix", "spotify", "amazon", "youtube",
    "hotstar", "apple", "google", "microsoft", "linkedin", "dropbox",
    "adobe", "zoom", "coursera", "swiggy", "zee5", "gym", "plan",
    "digital", "autorenew", "recurring",
}

FALSE_POSITIVE_TOKENS = {
    "salary", "wages", "payroll", "income", "stipend", "refund",
    "dividend", "interest", "deposit", "bonus",
}


# ── spaCy feature extractor ───────────────────────────────────────────────────

def _spacy_features(text: str) -> dict:
    """
    Extract NLP features using spaCy:
      - lemmatised tokens
      - POS tags
      - PhraseMatcher hits
    Returns feature dictionary.
    """
    if not SPACY_AVAILABLE or nlp is None:
        return {}

    doc = nlp(text.lower()[:200])  # limit length for performance

    lemmas    = {tok.lemma_ for tok in doc if not tok.is_stop and not tok.is_punct}
    pos_tags  = {tok.pos_ for tok in doc}

    has_sub_token   = int(bool(lemmas & SUBSCRIPTION_TOKENS))
    has_fp_token    = int(bool(lemmas & FALSE_POSITIVE_TOKENS))
    has_verb        = int("VERB" in pos_tags)
    has_propn       = int("PROPN" in pos_tags)
    token_count     = len(doc)

    return {
        "has_sub_token":  has_sub_token,
        "has_fp_token":   has_fp_token,
        "has_verb":       has_verb,
        "has_propn":      has_propn,
        "token_count":    token_count,
    }


def _preprocess(text: str) -> str:
    """Lower-case, strip noise for TF-IDF."""
    t = str(text).lower()
    t = re.sub(r'[^a-z\s]', ' ', t)
    return re.sub(r'\s+', ' ', t).strip()


# ── Custom sklearn transformers ───────────────────────────────────────────────

class SpacyFeatureExtractor(BaseEstimator, TransformerMixin):
    """Extracts spaCy numeric features from a list of strings."""

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        rows = []
        for text in X:
            feats = _spacy_features(str(text))
            rows.append([
                feats.get("has_sub_token", 0),
                feats.get("has_fp_token",  0),
                feats.get("has_verb",      0),
                feats.get("has_propn",     0),
                feats.get("token_count",   0),
            ])
        return np.array(rows, dtype=float)


class TextPreprocessor(BaseEstimator, TransformerMixin):
    """Applies _preprocess to each string."""

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return [_preprocess(str(t)) for t in X]


# ── False-positive guard (rule-based override) ────────────────────────────────

def _is_false_positive(text: str) -> bool:
    """Hard override: salary/refund/etc. are NEVER subscriptions."""
    low = text.lower()
    return any(fp in low for fp in FALSE_POSITIVE_TOKENS)


# ── Model training ────────────────────────────────────────────────────────────

def train_nlp_model(df: pd.DataFrame):
    """
    Train spaCy-enhanced TF-IDF + Logistic Regression pipeline.
    Prints full evaluation report (BRD §13: target ≥ 90% accuracy).

    Returns
    -------
    pipeline  : fitted sklearn Pipeline
    metrics   : dict with accuracy, precision, recall, f1
    """
    print(f"\n{'='*60}")
    print("  FR3 — NLP SUBSCRIPTION DETECTION (spaCy)")
    print(f"{'='*60}")
    print(f"  spaCy available : {SPACY_AVAILABLE}")

    desc_col = "Description_Clean" if "Description_Clean" in df.columns else "Description"
    X_raw    = df[desc_col].fillna("UNKNOWN").tolist()
    y        = df["SubscriptionFlag"].astype(int).values

    print(f"\n  Dataset size   : {len(df):,}")
    print(f"  Subscriptions  : {y.sum():,}  ({y.mean()*100:.1f}%)")
    print(f"  Non-subs       : {(1-y).sum():,}  ({(1-y).mean()*100:.1f}%)")

    # ── Build FeatureUnion: TF-IDF + spaCy numeric features ──────────────────
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import FunctionTransformer

    tfidf_pipeline = Pipeline([
        ("preprocess", TextPreprocessor()),
        ("tfidf", TfidfVectorizer(
            ngram_range=(1, 3),
            max_features=8000,
            min_df=2,
            sublinear_tf=True,
        )),
    ])

    if SPACY_AVAILABLE:
        from scipy.sparse import hstack, csr_matrix

        class CombinedFeatures(BaseEstimator, TransformerMixin):
            def __init__(self):
                self.tfidf_pipe = tfidf_pipeline
                self.spacy_ext  = SpacyFeatureExtractor()

            def fit(self, X, y=None):
                self.tfidf_pipe.fit(X, y)
                self.spacy_ext.fit(X, y)
                return self

            def transform(self, X):
                tfidf_feats  = self.tfidf_pipe.transform(X)
                spacy_feats  = csr_matrix(self.spacy_ext.transform(X))
                return hstack([tfidf_feats, spacy_feats])

        pipeline = Pipeline([
            ("features", CombinedFeatures()),
            ("clf", LogisticRegression(
                C=1.5,
                max_iter=1000,
                class_weight="balanced",
                random_state=42,
                solver="lbfgs",
            )),
        ])
    else:
        # Fallback: TF-IDF only
        pipeline = Pipeline([
            ("preprocess", TextPreprocessor()),
            ("tfidf", TfidfVectorizer(ngram_range=(1, 3), max_features=8000,
                                      min_df=2, sublinear_tf=True)),
            ("clf",   LogisticRegression(C=1.5, max_iter=1000,
                                         class_weight="balanced", random_state=42)),
        ])

    X_train, X_test, y_train, y_test = train_test_split(
        X_raw, y, test_size=0.20, random_state=42, stratify=y
    )

    pipeline.fit(X_train, y_train)

    # apply false-positive guard on test predictions
    y_pred_raw = pipeline.predict(X_test)
    y_prob_raw = pipeline.predict_proba(X_test)[:, 1]

    y_pred = np.array([
        0 if _is_false_positive(text) else pred
        for text, pred in zip(X_test, y_pred_raw)
    ])

    # ── Evaluation metrics (BRD §13) ─────────────────────────────────────────
    acc  = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    rec  = recall_score(y_test, y_pred, zero_division=0)
    f1   = f1_score(y_test, y_pred, zero_division=0)

    print(f"\n  ── Evaluation on held-out test set (20%) ──")
    print(f"  Accuracy   : {acc:.4f}  {'✅' if acc >= 0.90 else '⚠️ below target'} "
          f"  (BRD target ≥ 0.90)")
    print(f"  Precision  : {prec:.4f}")
    print(f"  Recall     : {rec:.4f}")
    print(f"  F1-Score   : {f1:.4f}")

    print(f"\n  Classification Report:")
    print(classification_report(y_test, y_pred,
                                target_names=["Non-Subscription", "Subscription"]))

    cm = confusion_matrix(y_test, y_pred)
    print(f"  Confusion Matrix:")
    print(f"                  Pred Non-Sub   Pred Sub")
    print(f"  Actual Non-Sub  {cm[0,0]:>10,}   {cm[0,1]:>8,}")
    print(f"  Actual Sub      {cm[1,0]:>10,}   {cm[1,1]:>8,}")

    # 5-fold cross-validation
    try:
        cv     = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        scores = cross_val_score(pipeline, X_raw, y, cv=cv, scoring="accuracy")
        print(f"\n  5-fold CV Accuracy : {scores.mean():.4f} ± {scores.std():.4f}")
    except Exception as e:
        print(f"\n  [CV skipped: {e}]")

    # ── Edge-case demos (BRD FR3) ─────────────────────────────────────────────
    edge_cases = [
        ("NETFLIX.COM MONTHLY SUB",     1),
        ("SPOTIFY PREMIUM MONTHLY",     1),
        ("AMAZON PRIME SUBSCRIPTION",   1),
        ("ELECTRICITY BILL AUTO PAY",   1),
        ("AUTO PAY 4521",               0),   # ambiguous
        ("ACH DEBIT 00293",             0),   # ambiguous
        ("NACH DEBIT MANDATE",          0),   # ambiguous
        ("MONTHLY SALARY CREDIT",       0),   # false-positive guard
        ("INTEREST CREDIT",             0),
        ("GROCERY PURCHASE BIGBASKET",  0),
        ("RESTAURANT BILL SWIGGY",      0),
        ("LINKEDIN PREMIUM CAREER",     1),
    ]
    print(f"\n  ── Edge-Case Classification (BRD FR3) ──")
    print(f"  {'Description':<40} {'Expected':<10} {'Predicted':<16} {'Confidence':>10}")
    print(f"  {'-'*78}")
    for desc, expected in edge_cases:
        proc    = _preprocess(desc)
        pred    = pipeline.predict([proc])[0]
        prob    = pipeline.predict_proba([proc])[0][1]
        # apply false-positive guard
        if _is_false_positive(desc):
            pred = 0
            prob = 0.0
        label   = "Sub ✅" if pred == 1 else "Non-Sub"
        exp_lbl = "Sub" if expected == 1 else "Non-Sub"
        match   = "✓" if pred == expected else "✗"
        print(f"  {desc:<40} {exp_lbl:<10} {label:<16} {prob:>9.2%}  {match}")

    print(f"{'='*60}\n")
    metrics = {"accuracy": acc, "precision": prec, "recall": rec, "f1": f1}
    return pipeline, metrics


def predict_subscriptions(pipeline, df: pd.DataFrame) -> pd.DataFrame:
    """
    Apply trained NLP pipeline to all rows.
    Adds columns: NLP_Sub_Pred, NLP_Sub_Prob.
    """
    desc_col = "Description_Clean" if "Description_Clean" in df.columns else "Description"
    texts    = df[desc_col].fillna("UNKNOWN").tolist()
    processed= [_preprocess(t) for t in texts]

    preds = pipeline.predict(processed)
    probs = pipeline.predict_proba(processed)[:, 1]

    # Apply false-positive guard
    preds = np.array([
        0 if _is_false_positive(str(t)) else p
        for t, p in zip(texts, preds)
    ])

    df = df.copy()
    df["NLP_Sub_Pred"] = preds
    df["NLP_Sub_Prob"] = probs.round(4)
    return df


if __name__ == "__main__":
    df = pd.read_csv("../data/transactions_cleaned.csv")
    model, metrics = train_nlp_model(df)
    df = predict_subscriptions(model, df)
    print(df[["Description_Clean","NLP_Sub_Pred","NLP_Sub_Prob"]].head(10))
