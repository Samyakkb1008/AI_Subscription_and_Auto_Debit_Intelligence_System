"""
FR8 — Insights Generation
Tech: Python + Pandas  [BRD §9]

Generates per-customer subscription insights as required by BRD FR8:
  "You have 5 active subscriptions."
  "Total monthly spend: ₹2,500"

Also produces system-level aggregated insights.
"""

import pandas as pd
import numpy as np


def generate_insights(df: pd.DataFrame,
                      summary_df: pd.DataFrame,
                      risk_df: pd.DataFrame,
                      pred_df: pd.DataFrame) -> pd.DataFrame:
    """
    Generate FR8 customer-level and system-level subscription insights.

    Returns
    -------
    pd.DataFrame — one row per customer with insight columns
    """
    print(f"\n{'='*60}")
    print("  FR8 — INSIGHTS GENERATION")
    print(f"{'='*60}")

    # ── Per-customer insights ─────────────────────────────────────────────────
    rows = []

    if summary_df.empty:
        print("  [FR8] No recurring summary data available.")
        return pd.DataFrame()

    for cust_id, grp in summary_df.groupby("CustomerID"):
        monthly = grp[grp["Frequency"] == "Monthly"]
        weekly  = grp[grp["Frequency"] == "Weekly"]

        monthly_count = len(monthly)
        weekly_count  = len(weekly)
        total_count   = len(grp)

        monthly_spend = monthly["Avg_Amount"].sum()
        weekly_spend  = weekly["Avg_Amount"].sum() * 4   # annualise to monthly equiv
        total_spend   = monthly_spend + weekly_spend

        # Risk info
        risk_row = risk_df[risk_df["CustomerID"] == cust_id]
        risk_lvl = risk_row["Risk_Level"].iloc[0] if not risk_row.empty else "Unknown"
        balance  = risk_row["Current_Balance"].iloc[0] if not risk_row.empty else 0

        # Upcoming debits
        upcoming_rows   = pred_df[pred_df["CustomerID"] == cust_id]
        upcoming_total  = upcoming_rows["Predicted_Amount"].sum() if not upcoming_rows.empty else 0
        next_due_date   = (upcoming_rows["Next_Debit_Date"].min()
                           if not upcoming_rows.empty else None)

        # FR8 message string (BRD FR8 output format)
        fr8_message = (
            f"You have {total_count} active subscription(s). "
            f"Total monthly spend: ₹{total_spend:,.2f}. "
            f"Next debit: {next_due_date}."
        )

        # Merchant list
        merchants = ", ".join(grp["Merchant"].unique()[:5])

        rows.append({
            "CustomerID":              cust_id,
            "Active_Subscriptions":    total_count,
            "Monthly_Subscriptions":   monthly_count,
            "Weekly_Subscriptions":    weekly_count,
            "Total_Monthly_Spend":     round(total_spend, 2),
            "Upcoming_Total":          round(upcoming_total, 2),
            "Next_Debit_Date":         next_due_date,
            "Current_Balance":         round(balance, 2),
            "Risk_Level":              risk_lvl,
            "Top_Merchants":           merchants,
            "FR8_Message":             fr8_message,
        })

    insights_df = pd.DataFrame(rows)

    # ── System-level summary ──────────────────────────────────────────────────
    print(f"\n  ── System-Level FR8 Summary ──")
    print(f"  Customers with subscriptions : {len(insights_df):,}")

    if not insights_df.empty:
        avg_subs  = insights_df["Active_Subscriptions"].mean()
        avg_spend = insights_df["Total_Monthly_Spend"].mean()
        max_spend = insights_df["Total_Monthly_Spend"].max()
        max_subs  = insights_df["Active_Subscriptions"].max()

        print(f"  Avg subscriptions/customer   : {avg_subs:.1f}")
        print(f"  Avg monthly spend            : ₹{avg_spend:,.2f}")
        print(f"  Max monthly spend            : ₹{max_spend:,.2f}")
        print(f"  Max subscriptions            : {max_subs}")

        # Sample FR8 messages
        print(f"\n  Sample FR8 Insight Messages:")
        for _, row in insights_df.head(5).iterrows():
            print(f"    [{row['CustomerID']}] {row['FR8_Message']}")

    print(f"{'='*60}\n")
    return insights_df


if __name__ == "__main__":
    summary = pd.read_csv("../data/recurring_summary.csv")
    risk    = pd.read_csv("../data/risk_scored.csv")
    pred    = pd.read_csv("../data/predictions.csv")
    df      = pd.read_csv("../data/transactions_patterns.csv")
    ins     = generate_insights(df, summary, risk, pred)
    print(ins[["CustomerID","Active_Subscriptions","Total_Monthly_Spend","FR8_Message"]].head())
