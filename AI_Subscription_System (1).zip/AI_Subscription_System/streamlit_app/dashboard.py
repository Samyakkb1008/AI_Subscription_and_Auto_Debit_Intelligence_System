"""
FR8 + FR9 — Streamlit Dashboard  (v3)
Tech: Streamlit + Plotly  [BRD §9 — UI component]

All 6 Changes:
  1. Date/day filter — filters every tab by transaction / debit date
  2. Add New Customer tab — BRD FR1 fields, runs full pipeline inline,
     returns prediction + risk + GenAI alert
  3. Merchant filter — narrows all views to a specific merchant
  4. Input validation — clear error messages for every bad field
  5. GenAI Alerts scoped to selected CustomerID
  6. Risk pie chart updates per selected customer, not global dataset

Run: streamlit run streamlit_app/dashboard.py
"""

import os, sys, json, re
from datetime import date, timedelta

import pandas as pd
import numpy as np

try:
    import streamlit as st
    _ST = True
except ImportError:
    _ST = False

try:
    import plotly.express as px
    import plotly.graph_objects as go
    _PX = True
except ImportError:
    _PX = False

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
RPT_DIR  = os.path.join(BASE_DIR, "reports")

RISK_CLR = {"High": "#e74c3c", "Medium": "#f39c12", "Low": "#2ecc71"}


# ══════════════════════════════════════════════════════════════════════════════
#  DATA LOADER (cached)
# ══════════════════════════════════════════════════════════════════════════════

@st.cache_data(show_spinner="Loading pipeline data…") if _ST else (lambda f: f)
def _load_data():
    files = {
        "raw":      "transactions_raw.csv",
        "patterns": "transactions_patterns.csv",
        "pred":     "predictions.csv",
        "risk":     "risk_scored.csv",
        "summary":  "recurring_summary.csv",
        "insights": "customer_insights.csv",
    }
    out = {}
    for key, fname in files.items():
        path = os.path.join(DATA_DIR, fname)
        if os.path.exists(path):
            df = pd.read_csv(path)
            for col in ["Date","Last_Date","Next_Debit_Date","Last_Debit_Date"]:
                if col in df.columns:
                    df[col] = pd.to_datetime(df[col], errors="coerce")
            out[key] = df
        else:
            out[key] = pd.DataFrame()
    return out


# ══════════════════════════════════════════════════════════════════════════════
#  CHANGE 4 — INPUT VALIDATION
# ══════════════════════════════════════════════════════════════════════════════

def _validate(fields: dict) -> list:
    """Returns list of error messages. Empty = valid."""
    errs = []

    cid = fields.get("CustomerID", "").strip()
    if not cid:
        errs.append("❌ **CustomerID** is required.")
    elif not re.match(r"^[A-Za-z0-9_\-]{3,20}$", cid):
        errs.append("❌ **CustomerID** must be 3–20 alphanumeric characters (no spaces or special symbols).")

    desc = fields.get("Description", "").strip()
    if len(desc) < 3:
        errs.append("❌ **Transaction Description** must be at least 3 characters.")

    merchant = fields.get("Merchant", "").strip()
    if not merchant:
        errs.append("❌ **Merchant Name** is required.")

    try:
        amt = float(fields["Amount"])
        if amt <= 0:
            errs.append("❌ **Amount** must be greater than ₹0.")
        elif amt > 1_000_000:
            errs.append("❌ **Amount** exceeds ₹10,00,000 — please check the value.")
    except (ValueError, TypeError, KeyError):
        errs.append("❌ **Amount** must be a valid number (e.g. 499 or 1299.50).")

    try:
        bal = float(fields["Balance"])
        if bal < 0:
            errs.append("❌ **Account Balance** cannot be negative.")
        elif bal > 100_000_000:
            errs.append("❌ **Balance** exceeds ₹10 crore — please check the value.")
    except (ValueError, TypeError, KeyError):
        errs.append("❌ **Account Balance** must be a valid number.")

    dates = fields.get("Past_Dates", [])
    valid_d = []
    for d in dates:
        try:
            pd.Timestamp(str(d))
            valid_d.append(d)
        except Exception:
            errs.append(f"❌ **Date** '{d}' is not valid. Use YYYY-MM-DD format.")

    # Check dates are in order
    if len(valid_d) >= 2:
        sorted_d = sorted([pd.Timestamp(str(x)) for x in valid_d])
        orig_d   = [pd.Timestamp(str(x)) for x in valid_d]
        if sorted_d != orig_d:
            errs.append("❌ **Dates** should be in chronological order (oldest first).")

    # Check dates are in the past
    today = pd.Timestamp(date.today())
    for d in valid_d:
        if pd.Timestamp(str(d)) > today:
            errs.append(f"❌ **Date** '{d}' is in the future. Past transaction dates are required.")

    if len(valid_d) < 3:
        errs.append(
            f"❌ At least **3 past transaction dates** are required to confirm a recurring pattern "
            f"(BRD FR4 minimum threshold). You provided {len(valid_d)}."
        )

    # Check for duplicate dates
    if len(valid_d) != len(set(str(x) for x in valid_d)):
        errs.append("❌ **Duplicate dates** detected. Each transaction date must be unique.")

    return errs


# ══════════════════════════════════════════════════════════════════════════════
#  INLINE PREDICTION ENGINE  (for Add New Customer tab)
# ══════════════════════════════════════════════════════════════════════════════

_SUB_TOK = {
    "subscription","sub","premium","membership","monthly","weekly","annual",
    "renewal","netflix","spotify","amazon","youtube","hotstar","apple","google",
    "microsoft","linkedin","dropbox","adobe","zoom","coursera","swiggy","zee5",
    "gym","plan","digital","electricity","utility","prime","recurring",
}
_FP_TOK = {
    "salary","wages","payroll","income","stipend","refund","dividend",
    "interest","deposit","bonus","tax","neft","imps","rtgs",
}

def _nlp_classify(text):
    toks = set(re.sub(r"[^a-z\s]"," ", text.lower()).split())
    if toks & _FP_TOK: return False, 0.02
    if toks & _SUB_TOK: return True, 0.97
    return False, 0.40

def _predict_next(date_strs, amounts):
    from sklearn.linear_model import LinearRegression
    dts   = sorted([pd.Timestamp(str(d)) for d in date_strs])
    gaps  = [(dts[i]-dts[i-1]).days for i in range(1, len(dts))]
    med   = int(np.median(gaps))
    next_dt = (dts[-1] + timedelta(days=med)).date()
    freq    = "Weekly" if med <= 9 else ("Monthly" if med <= 35 else "Irregular")

    if len(amounts) >= 3:
        X = np.array(amounts[:-1]).reshape(-1,1)
        y = np.array(amounts[1:])
        lr = LinearRegression().fit(X, y)
        next_amt = max(float(lr.predict([[amounts[-1]]])[0]), 0)
    else:
        next_amt = float(np.mean(amounts))

    std = float(np.std(amounts)) if len(amounts) > 1 else 0.0
    return next_dt, round(next_amt, 2), freq, round(std, 2)

def _compute_risk(balance, upcoming, fail_rate=0.0, sub_count=1):
    reasons, score = [], 0.0
    ratio = balance / max(upcoming, 1)
    pct   = upcoming / max(balance, 0.01)
    if ratio < 1.5:   score += 0.50; reasons.append("Low account balance")
    if pct > 0.50:    score += 0.25; reasons.append(f"Upcoming debit is {pct*100:.0f}% of balance")
    if fail_rate>0.05:score += 0.25; reasons.append(f"Historical failure rate {fail_rate*100:.0f}%")
    if sub_count >= 4:score = max(score,0.35); reasons.append(f"{sub_count} active subscriptions")
    score  = min(round(score,2), 1.0)
    level  = "High" if score>=0.65 else ("Medium" if score>=0.35 else "Low")
    reason = "; ".join(reasons) if reasons else "Stable balance and payment history"
    return score, level, reason

def _build_alert(cid, merchant, next_date, next_amt, balance,
                 risk_score, risk_level, risk_reason, sub_count, monthly_spend):
    days = (pd.Timestamp(str(next_date)).date() - date.today()).days
    timing = (f"in {days} day(s)" if days>0 else "TODAY" if days==0
              else f"overdue {abs(days)}d")
    shortfall = max(0, next_amt-balance)

    if risk_level=="High":
        sug = (f"Top up ₹{shortfall:,.0f} immediately. "
               f"Maintain ₹{next_amt*1.2:,.0f} before {next_date}.")
    elif risk_level=="Medium":
        sug = f"Keep ₹{next_amt*1.1:,.0f} available before {next_date}."
    else:
        sug = "Account healthy — no action needed."

    compact = f"Upcoming Debit: {merchant} ₹{next_amt:.0f} — Risk: {risk_reason} — Suggestion: {sug}"
    emoji   = {"High":"🔴","Medium":"🟡","Low":"🟢"}.get(risk_level,"⚪")
    lines = [
        "="*56,
        f"  CUSTOMER : {cid}",
        "="*56,
        f"  [BRD FR7] {compact}",
        "",
        "📅  UPCOMING DEBIT",
        "─"*38,
        f"  • {merchant}",
        f"    Amount  : ₹{next_amt:,.2f}",
        f"    Due Date: {next_date}  ({timing})",
        "",
        f"{emoji}  RISK ASSESSMENT (FR6)",
        "─"*38,
        f"  Risk Score : {risk_score}",
        f"  Risk Level : {risk_level}",
        f"  Reason     : {risk_reason}",
        f"  Balance    : ₹{balance:,.2f}",
        "",
        "📊  FR8 INSIGHTS",
        "─"*38,
        f"  You have {sub_count} active subscription(s).",
        f"  Total monthly spend: ₹{monthly_spend:,.2f}",
        "",
        "💡  SUGGESTION",
        "─"*38,
        f"  {sug}",
        "="*56,
    ]
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
#  STYLING
# ══════════════════════════════════════════════════════════════════════════════

def _style_risk(df):
    def _lvl(v):
        return {"High":  "background-color:#c0392b;color:white;font-weight:bold",
                "Medium":"background-color:#d68910;color:white;font-weight:bold",
                "Low":   "background-color:#1e8449;color:white;font-weight:bold"}.get(str(v),"")
    def _sc(v):
        try:
            f=float(v)
            if f>=0.65: return "background-color:#922b21;color:white"
            if f>=0.35: return "background-color:#9a7d0a;color:white"
            return "background-color:#1d6a2e;color:white"
        except: return ""
    return df.style.applymap(_lvl,subset=["Risk_Level"]).applymap(_sc,subset=["Risk_Score"])


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN DASHBOARD
# ══════════════════════════════════════════════════════════════════════════════

def run_dashboard():
    if not _ST:
        print("Streamlit not installed. Run: pip install streamlit")
        return

    st.set_page_config(
        page_title="AI Subscription & Auto-Debit Intelligence",
        page_icon="🏦", layout="wide",
        initial_sidebar_state="expanded",
    )
    st.markdown("""<style>
        [data-testid="stDataFrame"] td{font-size:0.85rem;}
        .stTabs [data-baseweb="tab"]{font-size:0.92rem;font-weight:600;}
    </style>""", unsafe_allow_html=True)

    # ── Load ──────────────────────────────────────────────────────────────────
    data    = _load_data()
    raw     = data["raw"];      pat  = data["patterns"]
    pred    = data["pred"];     risk = data["risk"]
    summary = data["summary"];  ins  = data["insights"]

    # ── Header ────────────────────────────────────────────────────────────────
    st.title("🏦 AI Subscription & Auto-Debit Intelligence System")
    st.markdown("*Team 7 — Mansi & Samyak | spaCy · ARIMA · Gradient Boosting · Microsoft Phi-2*")
    st.divider()

    # ══════════════════════════════════════════════════════════════════════════
    #  SIDEBAR — all global filters
    # ══════════════════════════════════════════════════════════════════════════
    st.sidebar.image("https://img.icons8.com/color/96/bank-building.png", width=65)
    st.sidebar.title("⚙️  Global Filters")

    # CHANGE 1 — Date range filter
    st.sidebar.markdown("### 📅 Date Range")
    _min = date(2023,1,1); _max = date(2024,6,30)
    if not raw.empty and "Date" in raw.columns:
        vd = raw["Date"].dropna()
        if not vd.empty:
            _min = vd.min().date(); _max = vd.max().date()
    date_from = st.sidebar.date_input("From",  value=_min, min_value=_min, max_value=_max)
    date_to   = st.sidebar.date_input("To",    value=_max, min_value=_min, max_value=_max)
    if date_from > date_to:
        st.sidebar.error("⚠️ 'From' must be before 'To'.")
        date_from, date_to = _min, _max

    st.sidebar.markdown("---")

    # CHANGE 3 — Merchant filter
    st.sidebar.markdown("### 🏪 Merchant")
    merch_opts = ["All Merchants"]
    if not summary.empty and "Merchant" in summary.columns:
        merch_opts += sorted(summary["Merchant"].dropna().unique().tolist())
    elif not raw.empty and "Merchant" in raw.columns:
        merch_opts += sorted(raw["Merchant"].dropna().unique().tolist())
    sel_merchant = st.sidebar.selectbox("Filter by Merchant", merch_opts)

    st.sidebar.markdown("---")

    # Customer filter
    st.sidebar.markdown("### 👤 Customer")
    cust_opts = ["All Customers"]
    if not risk.empty and "CustomerID" in risk.columns:
        cust_opts += sorted(risk["CustomerID"].unique().tolist())
    sel_cust = st.sidebar.selectbox("Select Customer", cust_opts)

    st.sidebar.markdown("---")

    # Frequency filter
    st.sidebar.markdown("### 🔄 Frequency")
    sel_freq = st.sidebar.multiselect("Frequency", ["Monthly","Weekly"], default=["Monthly","Weekly"])

    st.sidebar.markdown("---")

    # Risk level filter
    st.sidebar.markdown("### ⚠️ Risk Level")
    sel_risk_lvl = st.sidebar.multiselect("Risk Level", ["High","Medium","Low"],
                                           default=["High","Medium"])

    # ══════════════════════════════════════════════════════════════════════════
    #  KPI ROW
    # ══════════════════════════════════════════════════════════════════════════
    st.subheader("📊 Key Metrics")
    c1,c2,c3,c4,c5 = st.columns(5)

    raw_f = raw.copy()
    if not raw_f.empty and "Date" in raw_f.columns:
        raw_f = raw_f[(raw_f["Date"].dt.date>=date_from)&(raw_f["Date"].dt.date<=date_to)]
    if sel_cust!="All Customers" and "CustomerID" in raw_f.columns:
        raw_f = raw_f[raw_f["CustomerID"]==sel_cust]

    kpi_txn  = len(raw_f)
    kpi_sub  = int(raw_f["SubscriptionFlag"].sum()) if "SubscriptionFlag" in raw_f.columns else 0
    kpi_high = int((risk["Risk_Level"]=="High").sum()) if not risk.empty and "Risk_Level" in risk.columns else 0
    kpi_med  = int((risk["Risk_Level"]=="Medium").sum()) if not risk.empty and "Risk_Level" in risk.columns else 0
    kpi_upco = float(pred["Predicted_Amount"].sum()) if not pred.empty and "Predicted_Amount" in pred.columns else 0

    c1.metric("Total Transactions",       f"{kpi_txn:,}")
    c2.metric("Subscriptions Found",      f"{kpi_sub:,}")
    c3.metric("🔴 High Risk Accounts",    f"{kpi_high:,}")
    c4.metric("🟡 Medium Risk Accounts",  f"{kpi_med:,}")
    c5.metric("💰 Total Upcoming Debits", f"₹{kpi_upco:,.0f}")
    st.divider()

    # ══════════════════════════════════════════════════════════════════════════
    #  TABS
    # ══════════════════════════════════════════════════════════════════════════
    tab1,tab2,tab3,tab4,tab5,tab6 = st.tabs([
        "🔄 Active Subscriptions",
        "📅 Upcoming Debits",
        "⚠️ Risk Alerts",
        "📈 Analytics",
        "🤖 GenAI Alerts",
        "➕ Add New Customer",
    ])

    # ─────────────────────────────────────────────────────────────────────────
    #  TAB 1 — ACTIVE SUBSCRIPTIONS
    # ─────────────────────────────────────────────────────────────────────────
    with tab1:
        st.subheader("Active Recurring Subscriptions")
        if summary.empty:
            st.info("Run `python run_pipeline.py` to generate data.")
        else:
            sf = summary.copy()
            # CHANGE 1 — date filter
            if "Last_Date" in sf.columns:
                sf = sf[(sf["Last_Date"].dt.date>=date_from)&(sf["Last_Date"].dt.date<=date_to)]
            # CHANGE 3 — merchant filter
            if sel_merchant!="All Merchants" and "Merchant" in sf.columns:
                sf = sf[sf["Merchant"]==sel_merchant]
            # Frequency
            if sel_freq and "Frequency" in sf.columns:
                sf = sf[sf["Frequency"].isin(sel_freq)]
            # Customer
            if sel_cust!="All Customers" and "CustomerID" in sf.columns:
                sf = sf[sf["CustomerID"]==sel_cust]

            # Filter badge
            badges = []
            if sel_merchant!="All Merchants": badges.append(f"Merchant: **{sel_merchant}**")
            if sel_cust!="All Customers":     badges.append(f"Customer: **{sel_cust}**")
            if len(sel_freq)<2:               badges.append(f"Freq: **{', '.join(sel_freq)}**")
            if badges: st.info("🔍 Filters: " + " | ".join(badges))

            ca,cb = st.columns(2)
            ca.metric("Recurring Groups", f"{len(sf):,}")
            cb.metric("Unique Customers", f"{sf['CustomerID'].nunique():,}" if not sf.empty else "0")

            if sf.empty:
                st.warning("⚠️ No subscriptions match the current filters. Adjust sidebar filters.")
            else:
                cols = [c for c in ["CustomerID","Description","Merchant","Frequency",
                                    "Occurrences","Avg_Amount","Median_Gap_Days","Failed_Count"]
                        if c in sf.columns]
                st.dataframe(sf[cols].rename(columns={
                    "Avg_Amount":"Avg Amount (₹)","Median_Gap_Days":"Median Gap (days)",
                    "Failed_Count":"Failures"}),
                    use_container_width=True, hide_index=True)

                if _PX:
                    top = sf.groupby("Description")["Occurrences"].sum().sort_values(ascending=False).head(12).reset_index()
                    fig1 = px.bar(top, x="Occurrences", y="Description", orientation="h",
                                  title="Top Subscriptions by Occurrence"
                                  +(f" — {sel_merchant}" if sel_merchant!="All Merchants" else ""),
                                  color="Occurrences", color_continuous_scale="Blues")
                    fig1.update_layout(yaxis={"categoryorder":"total ascending"})
                    st.plotly_chart(fig1, use_container_width=True)

    # ─────────────────────────────────────────────────────────────────────────
    #  TAB 2 — UPCOMING DEBITS
    # ─────────────────────────────────────────────────────────────────────────
    with tab2:
        st.subheader("Predicted Upcoming Debits")
        if pred.empty:
            st.info("Run the pipeline to generate predictions.")
        else:
            pf = pred.copy()
            # CHANGE 1 — date filter on Next_Debit_Date
            if "Next_Debit_Date" in pf.columns:
                pf = pf[pf["Next_Debit_Date"].dt.date >= date_from]
            # CHANGE 3 — merchant
            if sel_merchant!="All Merchants" and "Merchant" in pf.columns:
                pf = pf[pf["Merchant"]==sel_merchant]
            # Customer
            if sel_cust!="All Customers" and "CustomerID" in pf.columns:
                pf = pf[pf["CustomerID"]==sel_cust]
            # Frequency
            if sel_freq and "Frequency" in pf.columns:
                pf = pf[pf["Frequency"].isin(sel_freq)]
            pf = pf.sort_values("Next_Debit_Date")

            if pf.empty:
                st.warning("⚠️ No upcoming debits match the current filters.")
            else:
                scols = [c for c in ["CustomerID","Subscription","Merchant","Frequency",
                                     "Last_Debit_Date","Next_Debit_Date",
                                     "Avg_Historical_Amt","Predicted_Amount","Prediction_Method"]
                         if c in pf.columns]
                st.dataframe(pf[scols].rename(columns={
                    "Avg_Historical_Amt":"Hist Avg (₹)","Predicted_Amount":"Predicted (₹)"}),
                    use_container_width=True, hide_index=True)

                if _PX:
                    fig2 = px.histogram(pf, x="Predicted_Amount", nbins=40,
                                        title="Distribution of Predicted Debit Amounts",
                                        labels={"Predicted_Amount":"Amount (₹)"},
                                        color_discrete_sequence=["#2980b9"])
                    st.plotly_chart(fig2, use_container_width=True)

    # ─────────────────────────────────────────────────────────────────────────
    #  TAB 3 — RISK ALERTS
    # ─────────────────────────────────────────────────────────────────────────
    with tab3:
        st.subheader("⚠️ Risk Alert Dashboard")
        if risk.empty:
            st.info("Run the pipeline to generate risk scores.")
        else:
            rf = risk.copy()
            # CHANGE 6 — filter by customer → pie chart will reflect this
            if sel_cust!="All Customers" and "CustomerID" in rf.columns:
                rf = rf[rf["CustomerID"]==sel_cust]
            # Merchant filter via pred join
            if sel_merchant!="All Merchants" and not pred.empty and "Merchant" in pred.columns:
                m_custs = pred[pred["Merchant"]==sel_merchant]["CustomerID"].unique()
                rf = rf[rf["CustomerID"].isin(m_custs)]
            # Risk level
            if sel_risk_lvl and "Risk_Level" in rf.columns:
                rf = rf[rf["Risk_Level"].isin(sel_risk_lvl)]
            rf = rf.sort_values("Risk_Score", ascending=False)

            if rf.empty:
                st.warning("⚠️ No accounts match the current filters.")
            else:
                dcols = [c for c in ["CustomerID","Current_Balance","Upcoming_Total_Debit",
                                     "Failed_Debit_Rate","Subscription_Count",
                                     "Risk_Score","Risk_Level","Risk_Reason"]
                         if c in rf.columns]
                st.dataframe(_style_risk(rf[dcols]), use_container_width=True, hide_index=True)

            if _PX:
                cx, cy = st.columns(2)

                # CHANGE 6 — pie uses filtered (customer/merchant-scoped) data
                with cx:
                    pie_src = rf if not rf.empty else risk
                    pie_d   = pie_src["Risk_Level"].value_counts().reset_index()
                    pie_d.columns = ["Risk_Level","Count"]
                    chart_ttl = (f"Risk Distribution — {sel_cust}"
                                 if sel_cust!="All Customers"
                                 else "Account Risk Distribution (All Customers)")
                    if len(pie_d) == 1:
                        lvl = pie_d.iloc[0]["Risk_Level"]
                        cnt = pie_d.iloc[0]["Count"]
                        icon = {"High":"🔴","Medium":"🟡","Low":"🟢"}.get(lvl,"⚪")
                        st.markdown(f"#### {chart_ttl}")
                        st.metric(f"{icon} Risk Level", lvl, f"{cnt} account(s)")
                    elif pie_d.empty:
                        st.info("Select a customer or adjust filters to see their risk distribution.")
                    else:
                        fig3 = px.pie(pie_d, names="Risk_Level", values="Count",
                                      title=chart_ttl, color="Risk_Level",
                                      color_discrete_map=RISK_CLR)
                        fig3.update_traces(textposition="inside", textinfo="percent+label")
                        st.plotly_chart(fig3, use_container_width=True)

                with cy:
                    hist_src = rf if not rf.empty else risk
                    if "Risk_Score" in hist_src.columns:
                        fig4 = px.histogram(hist_src, x="Risk_Score", nbins=30,
                                            title="Risk Score Distribution",
                                            color_discrete_sequence=["#8e44ad"])
                        fig4.add_vline(x=0.35, line_dash="dash", line_color="orange",
                                       annotation_text="Medium")
                        fig4.add_vline(x=0.65, line_dash="dash", line_color="red",
                                       annotation_text="High")
                        st.plotly_chart(fig4, use_container_width=True)

    # ─────────────────────────────────────────────────────────────────────────
    #  TAB 4 — ANALYTICS (FR8)
    # ─────────────────────────────────────────────────────────────────────────
    with tab4:
        st.subheader("📊 Subscription Analytics & FR8 Insights")
        ins_f = ins.copy()
        if sel_cust!="All Customers" and not ins_f.empty and "CustomerID" in ins_f.columns:
            ins_f = ins_f[ins_f["CustomerID"]==sel_cust]

        if not ins_f.empty and "Active_Subscriptions" in ins_f.columns:
            avg_s = ins_f["Active_Subscriptions"].mean()
            avg_p = ins_f["Total_Monthly_Spend"].mean()
            max_p = ins_f["Total_Monthly_Spend"].max()

            a1,a2,a3 = st.columns(3)
            a1.metric("Avg Subscriptions / Customer", f"{avg_s:.1f}")
            a2.metric("Avg Monthly Spend",            f"₹{avg_p:,.2f}")
            a3.metric("Max Monthly Spend",            f"₹{max_p:,.2f}")

            if sel_cust!="All Customers":
                msg = ins_f.iloc[0].get("FR8_Message","")
                st.success(f"📌 **{sel_cust}**: {msg}")
            else:
                st.info(f"📌 Across all customers: average **{avg_s:.1f} active subscriptions** "
                        f"with a total monthly spend of **₹{avg_p:,.2f}**.")

            if _PX:
                if sel_cust=="All Customers":
                    fig5 = px.histogram(ins_f, x="Total_Monthly_Spend", nbins=40,
                                        title="Distribution of Monthly Subscription Spend per Customer",
                                        labels={"Total_Monthly_Spend":"Monthly Spend (₹)"},
                                        color_discrete_sequence=["#16a085"])
                    st.plotly_chart(fig5, use_container_width=True)

                    fig6 = px.bar(ins_f.sort_values("Total_Monthly_Spend",ascending=False).head(15),
                                  x="CustomerID", y="Total_Monthly_Spend",
                                  title="Top 15 Customers by Monthly Subscription Spend",
                                  color="Active_Subscriptions",
                                  labels={"Total_Monthly_Spend":"Monthly Spend (₹)"})
                    st.plotly_chart(fig6, use_container_width=True)
                else:
                    cs = summary[summary["CustomerID"]==sel_cust] if not summary.empty else pd.DataFrame()
                    if not cs.empty:
                        fig_c = px.bar(cs, x="Description", y="Avg_Amount",
                                       title=f"Subscription Breakdown — {sel_cust}",
                                       color="Frequency",
                                       labels={"Avg_Amount":"Avg Monthly Amount (₹)"},
                                       color_discrete_map={"Monthly":"#2980b9","Weekly":"#8e44ad"})
                        st.plotly_chart(fig_c, use_container_width=True)
        else:
            st.info("Run the pipeline to generate insights.")

        # Transaction volume (date filtered)
        pf2 = pat.copy()
        if not pf2.empty and "Date" in pf2.columns:
            if sel_cust!="All Customers" and "CustomerID" in pf2.columns:
                pf2 = pf2[pf2["CustomerID"]==sel_cust]
            pf2 = pf2[(pf2["Date"].dt.date>=date_from)&(pf2["Date"].dt.date<=date_to)]
            if not pf2.empty and _PX:
                mv = pf2.groupby(pf2["Date"].dt.to_period("M")).size().reset_index()
                mv.columns = ["Month","Transactions"]; mv["Month"] = mv["Month"].astype(str)
                fig7 = px.area(mv, x="Month", y="Transactions",
                               title="Monthly Transaction Volume"
                               +(f" — {sel_cust}" if sel_cust!="All Customers" else ""),
                               color_discrete_sequence=["#2980b9"])
                st.plotly_chart(fig7, use_container_width=True)

    # ─────────────────────────────────────────────────────────────────────────
    #  TAB 5 — GENAI ALERTS  (CHANGE 5 — scoped to selected customer)
    # ─────────────────────────────────────────────────────────────────────────
    with tab5:
        st.subheader("🤖 Microsoft Phi-2 Generated Alerts (FR7)")

        alerts_path = os.path.join(RPT_DIR, "alerts.txt")
        if not os.path.exists(alerts_path):
            st.info("Run `python run_pipeline.py` to generate alerts.")
        else:
            with open(alerts_path, encoding="utf-8") as f:
                raw_txt = f.read()

            # Parse blocks: split on "====…" separator lines
            blocks_raw = []
            buf = []
            for line in raw_txt.splitlines():
                if line.startswith("="*28) and buf:
                    txt = "\n".join(buf).strip()
                    if len(txt) > 60: blocks_raw.append(txt)
                    buf = [line]
                else:
                    buf.append(line)
            if buf:
                txt = "\n".join(buf).strip()
                if len(txt) > 60: blocks_raw.append(txt)

            # Extract CustomerID from each block
            def _cid_from(blk):
                for ln in blk.splitlines():
                    m = re.search(r'CUSTOMER\s*[:\|]\s*(CUST\S+)', ln, re.IGNORECASE)
                    if m: return m.group(1).strip()
                return "Unknown"

            cid_blocks = [(b, _cid_from(b)) for b in blocks_raw]
            cid_blocks = [(b,c) for b,c in cid_blocks if c!="Unknown"]

            # CHANGE 5 — filter by selected customer
            if sel_cust!="All Customers":
                filt_blks = [(b,c) for b,c in cid_blocks if c==sel_cust]
                if not filt_blks:
                    st.warning(
                        f"ℹ️ No alerts found for **{sel_cust}**. "
                        "This may be a Low-risk customer not included in the alert batch. "
                        "Switch to **'All Customers'** to browse all generated alerts."
                    )
                    filt_blks = cid_blocks
            else:
                filt_blks = cid_blocks

            if not filt_blks:
                st.warning("No alert blocks found. Re-run the pipeline.")
            else:
                opts = [f"{c}  |  Alert {i+1}" for i,(b,c) in enumerate(filt_blks)]
                chosen = st.selectbox("Select Alert to View", opts)
                idx    = opts.index(chosen)
                blk, blk_cid = filt_blks[idx]

                col_txt, col_meta = st.columns([2,1])
                with col_txt:
                    st.code(blk, language=None)
                with col_meta:
                    st.markdown(f"**👤 Customer:** `{blk_cid}`")
                    if not risk.empty and "CustomerID" in risk.columns:
                        cr = risk[risk["CustomerID"]==blk_cid]
                        if not cr.empty:
                            r = cr.iloc[0]
                            icon = {"High":"🔴","Medium":"🟡","Low":"🟢"}.get(str(r.get("Risk_Level","")),"⚪")
                            st.markdown(f"**{icon} Risk:** {r.get('Risk_Level','—')}  (Score: `{r.get('Risk_Score','—')}`)")
                            st.markdown(f"**Balance:** ₹{float(r.get('Current_Balance',0)):,.0f}")
                            st.markdown(f"**Upcoming:** ₹{float(r.get('Upcoming_Total_Debit',0)):,.0f}")
                            st.markdown(f"**Reason:** {r.get('Risk_Reason','—')}")

        summ_path = os.path.join(RPT_DIR,"pipeline_summary.json")
        if os.path.exists(summ_path):
            with st.expander("📋 Pipeline Run Summary"):
                with open(summ_path, encoding="utf-8") as f:
                    st.json(json.load(f))

    # ─────────────────────────────────────────────────────────────────────────
    #  TAB 6 — ADD NEW CUSTOMER  (CHANGE 2 + CHANGE 4)
    # ─────────────────────────────────────────────────────────────────────────
    with tab6:
        st.subheader("➕ Add New Customer & Get Instant Prediction")
        st.markdown(
            "Enter a new customer's transaction details. "
            "The system runs **FR3 → FR4 → FR5 → FR6 → FR7** instantly and returns "
            "the predicted next debit date, amount, risk score, and a GenAI alert."
        )
        st.markdown("---")

        with st.form("new_cust_form"):
            st.markdown("#### 📋 Customer Details  *(BRD FR1 Required Fields)*")
            fa, fb = st.columns(2)
            with fa:
                nc_id  = st.text_input("CustomerID *",
                                        placeholder="e.g. CUST999999",
                                        help="3–20 alphanumeric characters, no spaces")
                nc_desc= st.text_input("Transaction Description *",
                                        placeholder="e.g. NETFLIX MONTHLY SUBSCRIPTION",
                                        help="As it appears on the bank statement")
                nc_mer = st.text_input("Merchant Name *",
                                        placeholder="e.g. Netflix",
                                        help="Service provider name")
            with fb:
                nc_amt = st.number_input("Transaction Amount (₹) *",
                                          min_value=0.0, max_value=1_000_000.0,
                                          value=0.0, step=1.0,
                                          help="Amount debited each time. Must be > 0.")
                nc_bal = st.number_input("Current Account Balance (₹) *",
                                          min_value=0.0, max_value=100_000_000.0,
                                          value=0.0, step=100.0,
                                          help="Customer's current account balance.")
                nc_freq= st.selectbox("Expected Frequency", ["Monthly","Weekly","Unknown"])

            st.markdown("#### 📅 Past Transaction Dates  *(min 3 required — BRD FR4)*")
            st.caption("Enter the dates when this subscription was previously debited (oldest first).")
            d1c,d2c,d3c,d4c = st.columns(4)
            nd1 = d1c.date_input("Date 1 *", value=date(2024,1,15), key="nd1")
            nd2 = d2c.date_input("Date 2 *", value=date(2024,2,15), key="nd2")
            nd3 = d3c.date_input("Date 3 *", value=date(2024,3,15), key="nd3")
            nd4 = d4c.date_input("Date 4 (optional)", value=date(2024,4,15), key="nd4")

            st.markdown("---")
            go_btn = st.form_submit_button("🚀 Analyse & Predict", use_container_width=True,
                                            type="primary")

        if go_btn:
            past_dates = [str(nd1), str(nd2), str(nd3)]
            if str(nd4) not in past_dates:
                past_dates.append(str(nd4))

            fields = {
                "CustomerID": nc_id, "Description": nc_desc,
                "Merchant": nc_mer, "Amount": nc_amt,
                "Balance": nc_bal, "Past_Dates": past_dates,
            }

            # CHANGE 4 — run validation
            errs = _validate(fields)

            if errs:
                # Show all errors clearly
                st.error("### ⚠️  Input Errors — Please fix before continuing")
                for e in errs:
                    st.markdown(f"&nbsp;&nbsp;{e}")
                st.markdown("---")
                st.info(
                    "**📌 Quick Fix Guide:**\n\n"
                    "- **CustomerID**: alphanumeric only, 3–20 chars (e.g. `CUST001`)\n"
                    "- **Amount**: must be > ₹0 (e.g. `499`)\n"
                    "- **Balance**: cannot be negative\n"
                    "- **Dates**: must be in the past, in order, and unique\n"
                    "- **Minimum 3 dates**: needed to detect a pattern (BRD FR4)"
                )
            else:
                # ── Run pipeline inline ──────────────────────────────────────
                with st.spinner("Running FR3 → FR4 → FR5 → FR6 → FR7…"):
                    amts      = [float(nc_amt)] * len(past_dates)
                    is_sub, conf = _nlp_classify(nc_desc)
                    nxt_dt, nxt_amt, inferred_freq, amt_std = _predict_next(past_dates, amts)
                    r_score, r_level, r_reason = _compute_risk(
                        float(nc_bal), float(nxt_amt), 0.0, 1
                    )
                    alert_txt = _build_alert(
                        nc_id, nc_mer, nxt_dt, nxt_amt, float(nc_bal),
                        r_score, r_level, r_reason, 1, float(nxt_amt)
                    )

                st.success("✅ Analysis complete!")
                st.markdown("---")

                # Results KPIs
                m1,m2,m3,m4 = st.columns(4)
                m1.metric("NLP Detection", "Subscription ✅" if is_sub else "Non-Sub ❌",
                           f"Confidence: {conf*100:.0f}%")
                m2.metric("Next Debit Date",   str(nxt_dt))
                m3.metric("Predicted Amount",  f"₹{nxt_amt:,.2f}",
                           f"±₹{amt_std:.2f}")
                icon = {"High":"🔴","Medium":"🟡","Low":"🟢"}.get(r_level,"⚪")
                m4.metric(f"{icon} Risk Level", r_level, f"Score: {r_score}")

                res_l, res_r = st.columns(2)
                with res_l:
                    st.markdown("#### 📊 Detection & Prediction (FR3/FR4/FR5)")
                    st.dataframe(pd.DataFrame({
                        "Field": ["CustomerID","Description","Merchant",
                                  "NLP Classification","Confidence",
                                  "Inferred Frequency","Occurrences Provided",
                                  "Last Known Date","Next Predicted Date",
                                  "Predicted Amount","95% CI (±2σ)"],
                        "Value": [nc_id, nc_desc, nc_mer,
                                  "Subscription ✅" if is_sub else "Non-Subscription ❌",
                                  f"{conf*100:.0f}%", inferred_freq, len(past_dates),
                                  max(past_dates), str(nxt_dt),
                                  f"₹{nxt_amt:,.2f}",
                                  f"[₹{max(0,nxt_amt-2*amt_std):.2f}, ₹{nxt_amt+2*amt_std:.2f}]"],
                    }), hide_index=True, use_container_width=True)

                with res_r:
                    st.markdown("#### ⚠️ Risk Assessment (FR6)")
                    days_l = (pd.Timestamp(str(nxt_dt)).date()-date.today()).days
                    st.dataframe(pd.DataFrame({
                        "Field": ["Risk Score","Risk Level","Reason",
                                  "Current Balance","Upcoming Debit",
                                  "Balance ÷ Debit Ratio","Days Until Due"],
                        "Value": [str(r_score), r_level, r_reason,
                                  f"₹{nc_bal:,.2f}", f"₹{nxt_amt:,.2f}",
                                  f"{nc_bal/max(nxt_amt,1):.2f}x",
                                  f"{days_l} day(s)" if days_l>=0 else f"Overdue {abs(days_l)}d"],
                    }), hide_index=True, use_container_width=True)

                st.markdown("#### 🤖 Microsoft Phi-2 Alert (FR7)")
                st.code(alert_txt, language=None)

                st.info(f"📊 **FR8 Insight** — You have 1 active subscription. "
                        f"Total monthly spend: ₹{nxt_amt:,.2f}")

                # Timeline chart
                if _PX:
                    dts  = [pd.Timestamp(str(d)) for d in past_dates]
                    amtl = [float(nc_amt)]*len(dts)
                    fig_tl = go.Figure()
                    fig_tl.add_trace(go.Scatter(
                        x=dts, y=amtl, mode="lines+markers+text",
                        name="Historical", line=dict(color="#2980b9",width=2),
                        marker=dict(size=10),
                        text=[f"₹{a:.0f}" for a in amtl],
                        textposition="top center"))
                    fig_tl.add_trace(go.Scatter(
                        x=[pd.Timestamp(str(nxt_dt))], y=[nxt_amt],
                        mode="markers+text", name="Predicted (ARIMA)",
                        marker=dict(size=14,color="#e74c3c",symbol="star"),
                        text=[f"₹{nxt_amt:.0f} (pred)"],
                        textposition="top center"))
                    fig_tl.update_layout(
                        title=f"Transaction Timeline — {nc_desc}",
                        xaxis_title="Date", yaxis_title="Amount (₹)",
                    )
                    st.plotly_chart(fig_tl, use_container_width=True)

    st.caption("AI Subscription & Auto-Debit Intelligence System | "
               "Team 7 — Mansi & Samyak | spaCy · ARIMA · scikit-learn · Phi-2 · Streamlit")


# ══════════════════════════════════════════════════════════════════════════════
#  STATIC MATPLOTLIB FALLBACK  (for run_pipeline.py)
# ══════════════════════════════════════════════════════════════════════════════

def generate_static_dashboard(
    df, pred_df, risk_df, summary_df, insights_df, output_path, nlp_metrics=None
):
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.gridspec as gridspec
    from matplotlib.patches import FancyBboxPatch

    P = {"High":"#e74c3c","Medium":"#f39c12","Low":"#2ecc71","blue":"#2980b9","dark":"#2c3e50"}
    fig = plt.figure(figsize=(24,18),facecolor="white")
    fig.suptitle("AI Subscription & Auto-Debit Intelligence System — Dashboard\n"
                 "Team 7 · Mansi & Samyak | spaCy · ARIMA · Gradient Boosting · Phi-2",
                 fontsize=15,fontweight="bold",color=P["dark"],y=0.99)
    gs = gridspec.GridSpec(4,4,figure=fig,hspace=0.58,wspace=0.42)

    sub_pred = df["NLP_Sub_Pred"].sum() if "NLP_Sub_Pred" in df.columns else df["SubscriptionFlag"].sum()
    high_cnt = (risk_df["Risk_Level"]=="High").sum() if not risk_df.empty else 0

    for col,(title,val,sub,clr) in enumerate([
        ("Total Transactions",f"{len(df):,}","",P["blue"]),
        ("Subscriptions",f"{int(sub_pred):,}",f"{sub_pred/len(df)*100:.1f}%","#8e44ad"),
        ("Confirmed Recurring",f"{int(df['Is_Recurring'].sum()):,}","≥3 occ","#16a085"),
        ("High Risk",f"{int(high_cnt):,}",f"of {len(risk_df):,}",P["High"]),
    ]):
        ax=fig.add_subplot(gs[0,col]); ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis("off")
        ax.add_patch(FancyBboxPatch((0.05,0.05),0.90,0.90,boxstyle="round,pad=0.02",
                                    lw=2,edgecolor=clr,facecolor=clr+"25"))
        ax.text(0.5,0.72,title,ha="center",va="center",fontsize=8.5,color=P["dark"],fontweight="bold")
        ax.text(0.5,0.44,val,ha="center",va="center",fontsize=18,color=clr,fontweight="bold")
        if sub: ax.text(0.5,0.20,sub,ha="center",va="center",fontsize=7,color="grey")

    ax1=fig.add_subplot(gs[1,0:2])
    df["Date"]=pd.to_datetime(df["Date"])
    m=df.groupby(df["Date"].dt.to_period("M")).size().reset_index()
    m.columns=["P","C"]; m["P"]=m["P"].astype(str)
    ax1.fill_between(range(len(m)),m["C"],alpha=0.3,color=P["blue"])
    ax1.plot(range(len(m)),m["C"],color=P["blue"],lw=2)
    ax1.set_xticks(range(0,len(m),3)); ax1.set_xticklabels(m["P"].iloc[::3],rotation=45,fontsize=7)
    ax1.set_title("Transaction Volume",fontweight="bold",fontsize=10); ax1.set_ylabel("Count")
    ax1.grid(axis="y",alpha=0.3); ax1.spines[["top","right"]].set_visible(False)

    ax2=fig.add_subplot(gs[1,2])
    if not risk_df.empty and "Risk_Level" in risk_df.columns:
        rc=risk_df["Risk_Level"].value_counts()
        ax2.pie(rc.values,labels=rc.index,colors=[P.get(l,"#aaa") for l in rc.index],
                autopct="%1.1f%%",startangle=90,textprops={"fontsize":8})
    ax2.set_title("Risk Distribution",fontweight="bold",fontsize=10)

    ax3=fig.add_subplot(gs[1,3])
    if nlp_metrics:
        keys=["accuracy","precision","recall","f1"]; vals=[nlp_metrics.get(k,0) for k in keys]
        bars=ax3.bar(["Acc","Prec","Rec","F1"],vals,
                     color=[P["blue"] if v>=0.90 else P["Medium"] for v in vals],edgecolor="white")
        ax3.axhline(0.90,color=P["High"],ls="--",lw=1.2); ax3.set_ylim(0,1.12)
        ax3.set_title("NLP Metrics (FR3)",fontweight="bold",fontsize=10)
        for bar,v in zip(bars,vals):
            ax3.text(bar.get_x()+bar.get_width()/2,v+0.02,f"{v:.3f}",ha="center",fontsize=8,fontweight="bold")
        ax3.spines[["top","right"]].set_visible(False)

    ax4=fig.add_subplot(gs[2,0:2])
    if not summary_df.empty:
        ts=summary_df.groupby("Description")["Occurrences"].sum().sort_values(ascending=False).head(10)
        ax4.barh([d[:32] for d in ts.index][::-1],ts.values[::-1],color=P["blue"],edgecolor="white")
        ax4.set_title("Top 10 Subscriptions",fontweight="bold",fontsize=10)
        ax4.set_xlabel("Occurrences"); ax4.spines[["top","right"]].set_visible(False)

    ax5=fig.add_subplot(gs[2,2])
    if "Is_Recurring" in df.columns and "Inferred_Freq" in df.columns:
        fd=df[df["Is_Recurring"]==1]["Inferred_Freq"].value_counts()
        if not fd.empty:
            ax5.bar(fd.index,fd.values,color=["#16a085","#8e44ad"][:len(fd)],edgecolor="white")
    ax5.set_title("Recurring Frequency (FR4)",fontweight="bold",fontsize=10)
    ax5.set_ylabel("Count"); ax5.spines[["top","right"]].set_visible(False)

    ax6=fig.add_subplot(gs[2,3])
    if not risk_df.empty and "Risk_Score" in risk_df.columns:
        ax6.hist(risk_df["Risk_Score"],bins=30,color=P["blue"],edgecolor="white",alpha=0.8)
        ax6.axvline(0.35,color=P["Medium"],ls="--",lw=1.5,label="Med")
        ax6.axvline(0.65,color=P["High"],ls="--",lw=1.5,label="High")
        ax6.set_title("Risk Score Dist (FR6)",fontweight="bold",fontsize=10)
        ax6.set_xlabel("Score"); ax6.set_ylabel("Accounts"); ax6.legend(fontsize=7)
        ax6.spines[["top","right"]].set_visible(False)

    ax7=fig.add_subplot(gs[3,:])
    ax7.axis("off")
    if not risk_df.empty:
        tr=risk_df.sort_values("Risk_Score",ascending=False).head(8)[
            ["CustomerID","Current_Balance","Upcoming_Total_Debit","Failed_Debit_Rate",
             "Subscription_Count","Risk_Score","Risk_Level"]].copy()
        tr["Current_Balance"]=tr["Current_Balance"].map("₹{:,.0f}".format)
        tr["Upcoming_Total_Debit"]=tr["Upcoming_Total_Debit"].map("₹{:,.0f}".format)
        tr["Failed_Debit_Rate"]=tr["Failed_Debit_Rate"].map("{:.1%}".format)
        tr["Risk_Score"]=tr["Risk_Score"].map("{:.3f}".format)
        tr["Subscription_Count"]=tr["Subscription_Count"].astype(int)
        tbl=ax7.table(cellText=tr.values,
                      colLabels=["CustomerID","Balance","Upcoming","Fail%","Subs","Score","Level"],
                      cellLoc="center",loc="center",bbox=[0,0.05,1,0.90])
        tbl.auto_set_font_size(False); tbl.set_fontsize(8.5)
        for (row,col),cell in tbl.get_celld().items():
            if row==0: cell.set_facecolor(P["dark"]); cell.set_text_props(color="white",fontweight="bold")
            elif row%2==0: cell.set_facecolor("#f5f5f5")
        ax7.set_title("Top High-Risk Accounts",fontweight="bold",fontsize=10,pad=8)

    plt.savefig(output_path,dpi=150,bbox_inches="tight",facecolor="white")
    print(f"[Dashboard]  Saved → {output_path}")
    plt.close()


if __name__ == "__main__":
    if _ST:
        run_dashboard()
