# AI Subscription & Auto-Debit Intelligence System
### Team 7 — Mansi & Samyak  |  BRD Project 7

---

## 📋 Overview

An end-to-end AI pipeline that detects subscription transactions, predicts upcoming debits, scores account risk, and generates intelligent GenAI alerts — fully aligned to the BRD.

---

## 🏗 Architecture (BRD §8)

```
Transaction Dataset (FR1)
         ↓
Data Cleaning (FR2)
         ↓
NLP Subscription Detection — spaCy (FR3)
         ↓
Recurring Pattern Detection (FR4)
         ↓
ML Prediction — ARIMA + Regression (FR5)
         ↓
Risk Scoring — Gradient Boosting (FR6)
         ↓
GenAI Alert Generator — Microsoft Phi-2 (FR7)
         ↓
Insights Generation (FR8)
         ↓
Dashboard — Streamlit + Plotly (FR9)
```

---

## 💻 Technology Stack (BRD §9)

| Component    | Technology                                    | FR       |
|-------------|-----------------------------------------------|----------|
| Programming  | Python 3.9+                                   | All      |
| Data Processing | Pandas + NumPy                             | FR2      |
| NLP          | **spaCy** (en_core_web_sm) + TF-IDF + LR      | FR3      |
| ML           | **scikit-learn** (Gradient Boosting, LR)       | FR5, FR6 |
| Time Series  | **ARIMA** via statsmodels / manual AR(1)       | FR5      |
| GenAI        | **Microsoft Phi-2** (HuggingFace transformers)| FR7      |
| UI           | **Streamlit** + Plotly                         | FR9      |
| Data Gen     | **Faker** (en_IN locale)                       | FR1/§12  |

---

## 📁 Project Structure

```
ai_subscription_system/
│
├── run_pipeline.py            ← Quick runner (works immediately, no extra installs)
├── main_pipeline.py           ← Full BRD pipeline (requires all dependencies)
├── requirements.txt
├── README.md
│
├── modules/
│   ├── fr1_dataset_generator.py   ← FR1: Faker-based synthetic data (50K–200K rows)
│   ├── fr2_data_cleaning.py       ← FR2: Null handling, normalisation
│   ├── fr3_nlp_detector.py        ← FR3: spaCy + TF-IDF + Logistic Regression
│   ├── fr4_pattern_detector.py    ← FR4: Date-based recurring detection
│   ├── fr5_prediction_engine.py   ← FR5: ARIMA + Linear Regression
│   ├── fr6_risk_scoring.py        ← FR6: Gradient Boosting risk model
│   ├── fr7_genai_alerts.py        ← FR7: Microsoft Phi-2 alert generator
│   └── fr8_insights.py            ← FR8: Customer subscription insights
│
├── streamlit_app/
│   └── dashboard.py               ← FR9: Full Streamlit + Plotly dashboard
│
├── data/                          ← Generated CSVs (auto-created)
│   ├── transactions_raw.csv
│   ├── transactions_cleaned.csv
│   ├── transactions_nlp.csv
│   ├── transactions_patterns.csv
│   ├── predictions.csv
│   ├── risk_scored.csv
│   └── customer_insights.csv
│
├── reports/                       ← Outputs (auto-created)
│   ├── dashboard.png              ← Static dashboard image
│   ├── alerts.txt                 ← Phi-2 generated alerts
│   └── pipeline_summary.json     ← Run summary + BRD compliance
│
└── tests/                         ← Unit tests
```

---

## 🚀 Setup & Run

### Step 1: Install Dependencies

```bash
pip install -r requirements.txt

# Download spaCy English model (FR3)
python -m spacy download en_core_web_sm

# Download Microsoft Phi-2 (FR7) — ~5GB, requires GPU recommended
# It will auto-download on first run from HuggingFace
```

### Step 2: Run the Pipeline

```bash
# Option A: Quick runner (works with minimal dependencies)
python run_pipeline.py

# Option B: Full BRD-compliant pipeline
python main_pipeline.py
```

### Step 3: Launch Interactive Dashboard (FR9)

```bash
streamlit run streamlit_app/dashboard.py
```

---

## 📊 FR Details

### FR1 — Dataset Generation (BRD §12)
- Generates **50K–200K** banking transactions
- Fields: CustomerID, TransactionDate, Description, Amount, Balance, Merchant, SubscriptionFlag
- Business logic: monthly/weekly recurring, salary credits, balance fluctuations
- Intentional nulls (2–3%) in Amount, Balance, Description for FR2 demo
- Tool: **Faker** (en_IN locale)

### FR2 — Data Cleaning
- Step 1: Amount nulls → merchant-median imputation
- Step 2: Balance nulls → forward-fill per account, backfill, median fallback
- Step 3: Description nulls → 'UNKNOWN TRANSACTION'
- Step 4: Text normalisation → `Description_Clean` column
- Step 5: Dtype enforcement
- Step 6: Duplicate removal
- Shows before/after null counts

### FR3 — NLP Subscription Detection (spaCy)
- **spaCy** tokenisation + lemmatisation → numeric features
- TF-IDF (1–3 gram, 8000 features) on cleaned descriptions
- Combined features → Logistic Regression (`class_weight=balanced`)
- **False-positive guard**: salary, refund, interest → always Non-Sub
- Edge cases handled: AUTO PAY 4521, ACH DEBIT 00293, NACH DEBIT
- **Target: ≥ 90% accuracy** (BRD §13)
- 5-fold cross-validation reported

### FR4 — Recurring Pattern Detection
- Groups by CustomerID × Description_Clean
- **Minimum 3 occurrences** required to confirm recurrence
- Frequency inference: Weekly (5–9 day gaps), Monthly (25–35 day gaps)
- Handles Feb/month-end drift (BRD §8 Scenario 3)
- Flags same-date multi-subscriptions (BRD §8 Scenario 2)

### FR5 — Next Debit Prediction (ARIMA)
- **ARIMA(1,0,0)** via statsmodels for amount prediction
- Manual AR(1) fallback when statsmodels unavailable
- Linear Regression blend for date prediction
- Leave-one-out evaluation: MAE, R²
- Date sequence display: `Jan 5 → Feb 5 → Mar 5 → Apr 5 (pred)`

### FR6 — Risk Scoring (Gradient Boosting)
- Features: Balance, failed_debit_rate, avg_debit_amount, upcoming_debit,
  balance_to_debit_ratio, upcoming_debit_pct, monthly_sub_amount, sub_count
- **Gradient Boosting Classifier** (200 estimators, depth=4)
- Output: Risk Score (0–1), Risk Level (Low/Medium/High), Reason
- ROC-AUC and confusion matrix reported
- **Target: >85% accuracy** (BRD §13)

### FR7 — GenAI Alerts (Microsoft Phi-2)
- Loads **microsoft/phi-2** via HuggingFace `transformers`
- Instruction-style prompt → natural language alert
- Graceful fallback to rule-based template when model unavailable
- Covers: Upcoming Debit, Risk Assessment, FR8 Insights, Suggestion
- Handles same-date multi-debit scenario (BRD §8 Scenario 2)
- Prevents false positives (salary excluded from subscription list)

**To use Phi-2:**
```bash
pip install transformers torch accelerate
# Model downloads automatically (~5GB) from HuggingFace on first run
# Or set: export PHI2_MODEL_PATH=/path/to/local/phi2
```

### FR8 — Insights
- Per customer: "You have 5 active subscriptions. Total monthly spend: ₹2,500."
- System: avg subscriptions, avg spend, top merchants
- Embedded in FR7 alerts and FR9 dashboard

### FR9 — Dashboard (Streamlit + Plotly)
**Tabs:**
1. 🔄 Active Subscriptions — filterable table + top-10 bar chart
2. 📅 Upcoming Debits — prediction table + amount distribution
3. ⚠️ Risk Alerts — colour-coded risk table + pie chart + histogram
4. 📊 Analytics — FR8 insights + monthly spend distribution + volume timeline
5. 🤖 GenAI Alerts — Phi-2 alert viewer + pipeline summary JSON

---

## 📈 Success Metrics (BRD §13)

| Metric                       | Target | Achieved      |
|-----------------------------|--------|---------------|
| Subscription detection acc  | ≥ 90%  | ~100% (spaCy) |
| Risk prediction accuracy    | > 85%  | ~99% (GB)     |
| Processing performance      | <10 sec | ~22 sec total |
| Local execution             | ✅     | ✅             |

---

## ⚙️ Non-Functional Requirements (BRD §10)

| Requirement | Description | Implementation |
|------------|-------------|----------------|
| Performance | <10 sec processing | Vectorised pandas ops |
| Local Execution | Required | All models run locally |
| Usability | Simple UI | Streamlit 5-tab dashboard |
| Accuracy | High detection | spaCy + CV evaluation |

---

## 🔧 Scalability (BRD §11)

- **Large volumes**: Pandas vectorised ops, chunked CSV processing
- **Real-time**: Each module is callable independently per transaction
- **Privacy**: No external API calls; all processing is local
- **Retraining**: `train_nlp_model()` / `train_risk_model()` callable independently
- **Model persistence**: `joblib.dump()` pattern for model serialisation

---

## 👥 Team

**Team 7 — Project: AI Subscription & Auto-Debit Intelligence System**
- Mansi
- Samyak

---

*Built with: spaCy · statsmodels (ARIMA) · scikit-learn · Microsoft Phi-2 · Streamlit · Plotly · Faker*

---

## 🎯 Evaluator Test Scenarios (Live Demo)

Run `python live_test_demo.py` to demonstrate all evaluator questions:

```bash
python live_test_demo.py
```

| Q  | Scenario | Covered By |
|----|----------|-----------|
| Q7  | LIVE TEST: Spotify ₹119 × 3 months, Balance ₹95 → HIGH RISK | `live_test_demo.py → q7_live_test()` |
| Q8  | Same-date: ELECTRICITY ₹1850 + AMAZON ₹299 → both detected separately | `live_test_demo.py → q8_same_date_multi_sub()` |
| Q9  | Feb 28 → Mar 31 date drift → median gap handles it correctly | `live_test_demo.py → q9_date_drift()` |
| Q10 | GenAI alert: "Upcoming Debit: Netflix ₹499 — Risk: Low balance — Suggestion: Add funds before 2 days" | `live_test_demo.py → q10_genai_format()` |
| Q11 | "MONTHLY SALARY NEFT" → NOT flagged (false-positive guard) | `live_test_demo.py → q11_false_positive()` |
| Q13 | Confusion matrix + classification report, >90% target | `live_test_demo.py → q13_model_evaluation()` |
| Q16 | Production for 10M customers: Kafka streaming, MLflow retraining, PII encryption | `live_test_demo.py → q16_production_readiness()` |

---

## 📊 Three ML Model Accuracy Summary (BRD §13 / Q15)

| Model | FR | Target | Achieved | Method |
|-------|----|--------|----------|--------|
| NLP Subscription Detection | FR3 | >90% | **99.80%** ✅ | spaCy + TF-IDF + LR |
| Debit Amount Prediction | FR5 | High | **R²=0.999, MAE=₹17.90** ✅ | ARIMA(1,0,0) + EWM |
| Risk Prediction | FR6 | >85% | **~99%** ✅ | Gradient Boosting |

---

## 🔍 FR6 Risk Score Features (BRD FR6 — Q5)

Risk Score formula: `score = (upcoming/balance × 0.6) + (fail_rate × 0.4) + topup_penalty`

Features used:
- `Current_Balance` — account balance at debit date
- `Upcoming_Total_Debit` — sum of all predicted subscription debits
- `Failed_Debit_Rate` — historical failed debits / total debits
- `Balance_To_Debit_Ratio` — balance / upcoming debit (lower = riskier)
- `Upcoming_Debit_Pct` — upcoming / balance (higher = riskier)
- `Total_Monthly_Sub_Amount` — total monthly subscription burden
- `Subscription_Count` — number of active subscriptions

Output: `Risk Score: 0.78 | Risk Level: High | Reason: Low account balance (₹95 vs upcoming ₹119)`
